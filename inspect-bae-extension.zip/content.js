"use strict";(()=>{var L=`
/* CSS Reset inside Shadow DOM */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
}

/* FAB - Floating Action Button */
.ib-fab {
  position: fixed;
  right: 24px;
  bottom: 24px;
  width: 52px;
  height: 52px;
  z-index: 2147483647;
  pointer-events: auto;
  cursor: grab;
  user-select: none;
  touch-action: none;
  border-radius: 50%;
  box-shadow: 0 8px 24px -4px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.1);
  transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s;
}

.ib-fab:active {
  cursor: grabbing;
  transform: scale(0.96);
}

.ib-fab-inner {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: linear-gradient(135deg, #18181b 0%, #09090b 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1.5px solid #27272a;
}

.ib-fab-icon {
  color: #a1a1aa;
  transition: color 0.2s, transform 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.ib-fab:hover .ib-fab-icon {
  color: #fafafa;
  transform: rotate(15deg);
}

.ib-fab-active .ib-fab-inner {
  background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
  border-color: #818cf8;
  box-shadow: 0 0 20px rgba(99, 102, 241, 0.6);
}

.ib-fab-active .ib-fab-icon {
  color: #ffffff;
  transform: rotate(90deg);
}

.ib-fab-pulse {
  display: none;
  position: absolute;
  inset: -4px;
  border-radius: 50%;
  border: 2px solid #818cf8;
  animation: ib-pulse 1.8s infinite;
}

.ib-fab-active .ib-fab-pulse {
  display: block;
}

@keyframes ib-pulse {
  0% { transform: scale(1); opacity: 0.8; }
  100% { transform: scale(1.4); opacity: 0; }
}

/* BOX MODEL OVERLAY */
.ib-overlay-container {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 2147483645;
}

.ib-box-model {
  position: fixed;
  pointer-events: none;
  transition: top 0.05s ease-out, left 0.05s ease-out, width 0.05s ease-out, height 0.05s ease-out;
}

/* Margin Layer - Orange */
.ib-box-margin {
  background-color: rgba(246, 178, 107, 0.35);
  border: 1px dashed rgba(230, 145, 56, 0.8);
}

/* Border Layer - Yellow/Amber */
.ib-box-border {
  background-color: rgba(255, 229, 153, 0.35);
  border: 1px solid rgba(241, 194, 50, 0.85);
}

/* Padding Layer - Green */
.ib-box-padding {
  background-color: rgba(182, 215, 168, 0.4);
  border: 1px dashed rgba(106, 168, 79, 0.85);
}

/* Content Layer - Soft Blue / Cyan */
.ib-box-content {
  background-color: rgba(111, 168, 220, 0.3);
  box-shadow: 0 0 0 1.5px #3b82f6;
}

/* FLOATING TOOLTIP CARD */
.ib-tooltip-card {
  position: fixed;
  width: 390px;
  max-height: 560px;
  background: #0e0e11;
  color: #e4e4e7;
  border-radius: 14px;
  border: 1px solid #27272a;
  box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.06);
  z-index: 2147483646;
  pointer-events: auto;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  font-size: 12px;
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  transition: box-shadow 0.2s ease, border-color 0.2s ease;
  animation: ib-pop 0.16s cubic-bezier(0.16, 1, 0.3, 1);
}

.ib-pinned {
  border-color: #6366f1 !important;
  box-shadow: 0 20px 40px -10px rgba(99, 102, 241, 0.35), 0 0 0 2px #6366f1 !important;
}

.ib-card-topbar {
  cursor: grab;
}

.ib-card-topbar:active {
  cursor: grabbing;
}

/* Topbar */
.ib-card-topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  background: #141418;
  border-bottom: 1px solid #1f1f23;
  user-select: none;
}

.ib-topbar-title {
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ib-logo-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #6366f1;
  box-shadow: 0 0 8px #6366f1;
}

.ib-brand {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #71717a;
}

.ib-tag-badge {
  font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  font-size: 12px;
  font-weight: 700;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.12);
  padding: 2px 6px;
  border-radius: 4px;
}

.ib-id-badge {
  font-family: ui-monospace, monospace;
  font-size: 11px;
  color: #f59e0b;
}

.ib-meta-dim {
  font-size: 11px;
  color: #71717a;
}

.ib-topbar-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.ib-icon-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  font-size: 12px;
  opacity: 0.7;
  transition: opacity 0.15s, background-color 0.15s;
}

.ib-icon-btn:hover {
  opacity: 1;
  background: rgba(255, 255, 255, 0.08);
}

.ib-icon-btn.ib-active {
  opacity: 1;
  background: rgba(99, 102, 241, 0.25);
}

.ib-close-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #a1a1aa;
}

.ib-close-btn:hover {
  background: rgba(239, 68, 68, 0.2) !important;
  color: #f87171 !important;
  opacity: 1;
}

/* Card Content Body */
.ib-card-content {
  overflow-y: auto;
  max-height: 440px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ib-card-content::-webkit-scrollbar {
  width: 5px;
}
.ib-card-content::-webkit-scrollbar-thumb {
  background: #27272a;
  border-radius: 3px;
}

/* Framework Bar */
.ib-fw-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.ib-fw-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 8px;
  border-radius: 9999px;
  font-size: 11px;
  font-weight: 600;
}

.ib-react-pill {
  background: rgba(0, 216, 255, 0.12);
  color: #38bdf8;
  border: 1px solid rgba(0, 216, 255, 0.25);
}

.ib-radix-pill {
  background: rgba(142, 78, 198, 0.14);
  color: #c084fc;
  border: 1px solid rgba(142, 78, 198, 0.3);
}

.ib-pill-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.ib-pill-state {
  font-size: 10px;
  opacity: 0.8;
}

.ib-tw-pill {
  background: rgba(14, 165, 233, 0.12);
  color: #38bdf8;
  border: 1px solid rgba(14, 165, 233, 0.25);
}

/* Dimension Strip */
.ib-dim-strip {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 6px;
  background: #141418;
  padding: 8px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-dim-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ib-dim-label {
  font-size: 10px;
  color: #71717a;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.ib-dim-val {
  font-size: 11px;
  font-weight: 600;
  color: #f4f4f5;
  font-family: ui-monospace, monospace;
}

/* Sections */
.ib-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ib-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  font-weight: 700;
  color: #a1a1aa;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.ib-count {
  background: #27272a;
  color: #d4d4d8;
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 9999px;
}

.ib-btn-subtle {
  background: none;
  border: none;
  color: #6366f1;
  cursor: pointer;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 4px;
  border-radius: 3px;
}

.ib-btn-subtle:hover {
  background: rgba(99, 102, 241, 0.12);
  color: #818cf8;
}

.ib-grid-2col {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px 12px;
  background: #141418;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-col-span-2 {
  grid-column: span 2;
}

.ib-prop-row {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.ib-prop-key {
  font-size: 10px;
  color: #71717a;
}

.ib-prop-val {
  font-size: 11px;
  color: #f4f4f5;
  font-family: ui-monospace, monospace;
  word-break: break-all;
}

.ib-truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ib-font-name {
  display: flex;
  align-items: center;
  gap: 4px;
}

.ib-webfont-tag {
  font-size: 9px;
  background: rgba(16, 185, 129, 0.15);
  color: #34d399;
  border: 1px solid rgba(16, 185, 129, 0.3);
  padding: 1px 4px;
  border-radius: 3px;
  font-family: sans-serif;
  text-transform: uppercase;
}

/* Color Swatches */
.ib-color-wrap {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
}

.ib-swatch {
  width: 13px;
  height: 13px;
  border-radius: 3px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  flex-shrink: 0;
}

.ib-swatch-trans {
  background: repeating-conic-gradient(#3f3f46 0% 25%, #27272a 0% 50%) 50% / 6px 6px;
}

.ib-color-hex {
  font-size: 11px;
}

.ib-tw-mini-tag {
  font-size: 9px;
  background: #27272a;
  color: #38bdf8;
  padding: 1px 4px;
  border-radius: 3px;
  font-family: ui-monospace, monospace;
}

/* Mini Box Model Visualizer */
.ib-mini-boxmodel {
  background: #141418;
  border: 1px solid #1f1f23;
  border-radius: 8px;
  padding: 8px;
  display: flex;
  justify-content: center;
}

.ib-bm-margin {
  background: rgba(246, 178, 107, 0.15);
  border: 1px dashed rgba(230, 145, 56, 0.6);
  padding: 6px;
  border-radius: 6px;
  text-align: center;
  width: 100%;
}

.ib-bm-padding {
  background: rgba(182, 215, 168, 0.2);
  border: 1px dashed rgba(106, 168, 79, 0.6);
  padding: 6px;
  border-radius: 4px;
  margin-top: 4px;
}

.ib-bm-content {
  background: rgba(111, 168, 220, 0.25);
  border: 1px solid #3b82f6;
  border-radius: 3px;
  padding: 4px 0;
  font-size: 10px;
  font-family: ui-monospace, monospace;
  color: #93c5fd;
  font-weight: 600;
  margin-top: 4px;
}

.ib-bm-label {
  font-size: 9px;
  font-family: ui-monospace, monospace;
  color: #a1a1aa;
}

/* Tailwind Pills */
.ib-pills-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  background: #141418;
  padding: 8px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-tw-badge {
  font-family: ui-monospace, monospace;
  font-size: 11px;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.1);
  border: 1px solid rgba(56, 189, 248, 0.2);
  padding: 2px 6px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.15s, color 0.15s;
}

.ib-tw-badge:hover {
  background: rgba(56, 189, 248, 0.25);
  color: #ffffff;
}

.ib-more-badge {
  font-size: 10px;
  color: #71717a;
  padding: 2px 4px;
  align-self: center;
}

/* CSS Variables Grid */
.ib-vars-grid {
  display: flex;
  flex-direction: column;
  gap: 4px;
  background: #141418;
  padding: 8px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-var-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-family: ui-monospace, monospace;
  font-size: 10.5px;
  padding: 3px 6px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.02);
  cursor: pointer;
}

.ib-var-item:hover {
  background: rgba(99, 102, 241, 0.15);
}

.ib-var-name {
  color: #c084fc;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 55%;
}

.ib-var-val {
  color: #94a3b8;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 40%;
}

/* Copy Toolbar */
.ib-copy-toolbar {
  display: flex;
  gap: 6px;
  padding: 10px 14px;
  background: #141418;
  border-top: 1px solid #1f1f23;
  flex-shrink: 0;
}

/* Mode Tabs */
.ib-mode-tabs {
  display: flex;
  background: #141418;
  border-bottom: 1px solid #1f1f23;
  padding: 4px 10px;
  gap: 6px;
  flex-shrink: 0;
}

.ib-tab-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 10px;
  background: transparent;
  border: none;
  border-radius: 6px;
  color: #a1a1aa;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}

.ib-tab-btn:hover {
  color: #fafafa;
  background: rgba(255, 255, 255, 0.05);
}

.ib-tab-btn.ib-tab-active {
  color: #ffffff;
  background: #27272a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}

.ib-tab-badge {
  background: #6366f1;
  color: #ffffff;
  font-size: 9px;
  font-weight: 700;
  padding: 1px 5px;
  border-radius: 9999px;
  line-height: 1;
}

/* Custom Values Editor */
.ib-custom-container {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ib-custom-status-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #141418;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-custom-status-text {
  font-size: 11px;
  color: #a1a1aa;
  display: flex;
  align-items: center;
  gap: 6px;
}

.ib-live-indicator {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 6px #10b981;
}

.ib-btn-reset-all {
  background: transparent;
  border: 1px solid rgba(244, 63, 94, 0.4);
  color: #fb7185;
  font-size: 10px;
  font-weight: 600;
  padding: 3px 8px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.ib-btn-reset-all:hover {
  background: rgba(244, 63, 94, 0.15);
  border-color: #f43f5e;
  color: #ffffff;
}

.ib-custom-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ib-custom-sec-title {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #71717a;
  padding-left: 2px;
}

.ib-custom-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  background: #141418;
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-field-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.ib-field-group.ib-col-span-2 {
  grid-column: span 2;
}

.ib-field-label {
  font-size: 10px;
  color: #858592;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 500;
}

.ib-changed-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #818cf8;
  box-shadow: 0 0 6px #818cf8;
  display: inline-block;
}

.ib-input {
  background: #09090b;
  border: 1px solid #27272a;
  border-radius: 6px;
  color: #fafafa;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 6px 8px;
  width: 100%;
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s, background-color 0.15s;
}

.ib-input:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
}

.ib-input.ib-input-changed {
  border-color: #6366f1;
  background: rgba(99, 102, 241, 0.08);
}

.ib-color-picker-row {
  display: flex;
  align-items: center;
  gap: 6px;
}

.ib-color-input-native {
  -webkit-appearance: none;
  border: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  cursor: pointer;
  background: transparent;
  padding: 0;
  flex-shrink: 0;
}

.ib-color-input-native::-webkit-color-swatch-wrapper {
  padding: 0;
}

.ib-color-input-native::-webkit-color-swatch {
  border: 1px solid #3f3f46;
  border-radius: 5px;
}

.ib-select {
  background: #09090b;
  border: 1px solid #27272a;
  border-radius: 6px;
  color: #fafafa;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 6px 8px;
  width: 100%;
  outline: none;
  cursor: pointer;
}

.ib-select:focus {
  border-color: #6366f1;
}

.ib-select.ib-input-changed {
  border-color: #6366f1;
  background: rgba(99, 102, 241, 0.08);
}

.ib-copy-note-btn {
  background: #4f46e5 !important;
  color: #ffffff !important;
  border-color: #6366f1 !important;
  font-weight: 700 !important;
}

.ib-copy-note-btn:hover {
  background: #4338ca !important;
  box-shadow: 0 0 12px rgba(99, 102, 241, 0.4) !important;
}

.ib-action-btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  background: #1c1c21;
  color: #d4d4d8;
  border: 1px solid #2e2e34;
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}

.ib-action-btn:hover {
  background: #27272a;
  color: #ffffff;
  border-color: #3f3f46;
}

.ib-action-btn:active {
  transform: scale(0.98);
}

/* Toast Notification */
.ib-toast {
  position: fixed;
  bottom: 84px;
  right: 24px;
  background: #10b981;
  color: #ffffff;
  font-size: 12px;
  font-weight: 600;
  padding: 8px 14px;
  border-radius: 8px;
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
  z-index: 2147483647;
  pointer-events: auto;
  display: flex;
  align-items: center;
  gap: 6px;
  animation: ib-toast-anim 2s forwards;
}

@keyframes ib-toast-anim {
  0% { opacity: 0; transform: translateY(10px); }
  15% { opacity: 1; transform: translateY(0); }
  85% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-8px); }
}
`;var M=class{container;marginEl;borderEl;paddingEl;contentEl;constructor(e){this.container=document.createElement("div"),this.container.className="ib-overlay-container",this.marginEl=document.createElement("div"),this.marginEl.className="ib-box-model ib-box-margin",this.borderEl=document.createElement("div"),this.borderEl.className="ib-box-model ib-box-border",this.paddingEl=document.createElement("div"),this.paddingEl.className="ib-box-model ib-box-padding",this.contentEl=document.createElement("div"),this.contentEl.className="ib-box-model ib-box-content",this.container.appendChild(this.marginEl),this.container.appendChild(this.borderEl),this.container.appendChild(this.paddingEl),this.container.appendChild(this.contentEl),e.appendChild(this.container)}update(e,t){let i=e.getBoundingClientRect(),{margin:a,padding:l,border:n}=t.boxModel,r=window.scrollX,s=window.scrollY,p=i.top+n.top+l.top,b=i.left+n.left+l.left,f=Math.max(0,i.width-n.left-n.right-l.left-l.right),c=Math.max(0,i.height-n.top-n.bottom-l.top-l.bottom),u=i.top+n.top,y=i.left+n.left,C=Math.max(0,i.width-n.left-n.right),$=Math.max(0,i.height-n.top-n.bottom),d=i.top,g=i.left,h=i.width,x=i.height,v=i.top-a.top,E=i.left-a.left,W=i.width+a.left+a.right,_=i.height+a.top+a.bottom;this.applyBox(this.marginEl,v,E,W,_),this.applyBox(this.borderEl,d,g,h,x),this.applyBox(this.paddingEl,u,y,C,$),this.applyBox(this.contentEl,p,b,f,c),this.container.style.display="block"}applyBox(e,t,i,a,l){e.style.top=`${t}px`,e.style.left=`${i}px`,e.style.width=`${a}px`,e.style.height=`${l}px`}hide(){this.container.style.display="none"}destroy(){this.container.remove()}};var O={"slate-50":"#f8fafc","slate-100":"#f1f5f9","slate-200":"#e2e8f0","slate-300":"#cbd5e1","slate-400":"#94a3b8","slate-500":"#64748b","slate-600":"#475569","slate-700":"#334155","slate-800":"#1e293b","slate-900":"#0f172a","slate-950":"#020617","gray-50":"#f9fafb","gray-100":"#f3f4f6","gray-200":"#e5e7eb","gray-300":"#d1d5db","gray-400":"#9ca3af","gray-500":"#6b7280","gray-600":"#4b5563","gray-700":"#374151","gray-800":"#1f2937","gray-900":"#111827","gray-950":"#030712","zinc-50":"#fafafa","zinc-100":"#f4f4f5","zinc-200":"#e4e4e7","zinc-300":"#d4d4d8","zinc-400":"#a1a1aa","zinc-500":"#71717a","zinc-600":"#52525b","zinc-700":"#3f3f46","zinc-800":"#27272a","zinc-900":"#18181b","zinc-950":"#09090b","neutral-50":"#fafafa","neutral-100":"#f5f5f5","neutral-200":"#e5e5e5","neutral-300":"#d4d4d4","neutral-400":"#a3a3a3","neutral-500":"#737373","neutral-600":"#525252","neutral-700":"#404040","neutral-800":"#262626","neutral-900":"#171717","neutral-950":"#0a0a0a","red-50":"#fef2f2","red-100":"#fee2e2","red-200":"#fecaca","red-300":"#fca5a5","red-400":"#f87171","red-500":"#ef4444","red-600":"#dc2626","red-700":"#b91c1c","red-800":"#991b1b","red-900":"#7f1d1d","red-950":"#450a0a","orange-50":"#fff7ed","orange-100":"#ffedd5","orange-200":"#fed7aa","orange-300":"#fdba74","orange-400":"#fb923c","orange-500":"#f97316","orange-600":"#ea580c","orange-700":"#c2410c","orange-800":"#9a3412","orange-900":"#7c2d12","orange-950":"#431407","amber-50":"#fffbeb","amber-100":"#fef3c7","amber-200":"#fde68a","amber-300":"#fcd34d","amber-400":"#fbbf24","amber-500":"#f59e0b","amber-600":"#d97706","amber-700":"#b45309","amber-800":"#92400e","amber-900":"#78350f","amber-950":"#451a03","yellow-50":"#fefce8","yellow-100":"#fef9c3","yellow-200":"#fef08a","yellow-300":"#fde047","yellow-400":"#facc15","yellow-500":"#eab308","yellow-600":"#ca8a04","yellow-700":"#a16207","yellow-800":"#854d0e","yellow-900":"#713f12","yellow-950":"#422006","green-50":"#f0fdf4","green-100":"#dcfce7","green-200":"#bbf7d0","green-300":"#86efac","green-400":"#4ade80","green-500":"#22c55e","green-600":"#16a34a","green-700":"#15803d","green-800":"#166534","green-900":"#14532d","green-950":"#052e16","emerald-50":"#ecfdf5","emerald-100":"#d1fae5","emerald-200":"#a7f3d0","emerald-300":"#6ee7b7","emerald-400":"#34d399","emerald-500":"#10b981","emerald-600":"#059669","emerald-700":"#047857","emerald-800":"#065f46","emerald-900":"#064e3b","emerald-950":"#022c22","teal-50":"#f0fdfa","teal-100":"#ccfbf1","teal-200":"#99f6e4","teal-300":"#5eead4","teal-400":"#2dd4bf","teal-500":"#14b8a6","teal-600":"#0d9488","teal-700":"#0f766e","teal-800":"#115e59","teal-900":"#134e4a","teal-950":"#042f2e","cyan-50":"#ecfeff","cyan-100":"#cffafe","cyan-200":"#a5f3fc","cyan-300":"#67e8f9","cyan-400":"#22d3ee","cyan-500":"#06b6d4","cyan-600":"#0891b2","cyan-700":"#0e7490","cyan-800":"#155e75","cyan-900":"#164e63","cyan-950":"#083344","sky-50":"#f0f9ff","sky-100":"#e0f2fe","sky-200":"#bae6fd","sky-300":"#7dd3fc","sky-400":"#38bdf8","sky-500":"#0ea5e9","sky-600":"#0284c7","sky-700":"#0369a1","sky-800":"#075985","sky-900":"#0c4a6e","sky-950":"#082f49","blue-50":"#eff6ff","blue-100":"#dbeafe","blue-200":"#bfdbfe","blue-300":"#93c5fd","blue-400":"#60a5fa","blue-500":"#3b82f6","blue-600":"#2563eb","blue-700":"#1d4ed8","blue-800":"#1e40af","blue-900":"#1e3a8a","blue-950":"#172554","indigo-50":"#eef2ff","indigo-100":"#e0e7ff","indigo-200":"#c7d2fe","indigo-300":"#a5b4fc","indigo-400":"#818cf8","indigo-500":"#6366f1","indigo-600":"#4f46e5","indigo-700":"#4338ca","indigo-800":"#3730a3","indigo-900":"#312e81","indigo-950":"#1e1b4b","violet-50":"#f5f3ff","violet-100":"#ede9fe","violet-200":"#ddd6fe","violet-300":"#c4b5fd","violet-400":"#a78bfa","violet-500":"#8b5cf6","violet-600":"#7c3aed","violet-700":"#6d28d9","violet-800":"#5b21b6","violet-900":"#4c1d95","violet-950":"#2e1065","purple-50":"#faf5ff","purple-100":"#f3e8ff","purple-200":"#e9d5ff","purple-300":"#d8b4fe","purple-400":"#c084fc","purple-500":"#a855f7","purple-600":"#9333ea","purple-700":"#7e22ce","purple-800":"#6b21a8","purple-900":"#581c87","purple-950":"#3b0764","fuchsia-50":"#fdf4ff","fuchsia-100":"#fae8ff","fuchsia-200":"#f5d0fe","fuchsia-300":"#f0abfc","fuchsia-400":"#e879f9","fuchsia-500":"#d946ef","fuchsia-600":"#c026d3","fuchsia-700":"#a21caf","fuchsia-800":"#86198f","fuchsia-900":"#701a75","fuchsia-950":"#4a044e","pink-50":"#fdf2f8","pink-100":"#fce7f3","pink-200":"#fbcfe8","pink-300":"#f9a8d4","pink-400":"#f472b6","pink-500":"#ec4899","pink-600":"#db2777","pink-700":"#be185d","pink-800":"#9d174d","pink-900":"#831843","pink-950":"#500724","rose-50":"#fff1f2","rose-100":"#ffe4e6","rose-200":"#fecdd3","rose-300":"#fda4af","rose-400":"#fb7185","rose-500":"#f43f5e","rose-600":"#e11d48","rose-700":"#be123c","rose-800":"#9f1239","rose-900":"#881337","rose-950":"#4c0519",black:"#000000",white:"#ffffff"};function w(o,e,t){if(!o||o==="transparent"||o==="rgba(0, 0, 0, 0)")return{hex:"transparent",rgb:"transparent",hsl:"transparent",alpha:0,raw:o||"transparent"};if(o.startsWith("#")){let a=o,{r:l,g:n,b:r,a:s}=q(a),p=s===1?`rgb(${l}, ${n}, ${r})`:`rgba(${l}, ${n}, ${r}, ${s.toFixed(2)})`,b=B(l,n,r);return{hex:a,rgb:p,hsl:b,alpha:s,raw:o,tailwindClass:S(a)}}let i=o.match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)/);if(i){let a=Math.round(parseFloat(i[1])),l=Math.round(parseFloat(i[2])),n=Math.round(parseFloat(i[3])),r=i[4]!==void 0?parseFloat(i[4]):1,s=Y(a,l,n,r),p=r===1?`rgb(${a}, ${l}, ${n})`:`rgba(${a}, ${l}, ${n}, ${r})`,b=B(a,l,n),f=S(s);return!f&&r===1&&(f=S(s.slice(0,7))),{hex:s,rgb:p,hsl:b,alpha:r,raw:o,tailwindClass:f}}return{hex:o,rgb:o,hsl:o,alpha:1,raw:o}}function q(o){let e=o.replace("#","");if(e.length===3&&(e=e.split("").map(t=>t+t).join("")),e.length===6){let t=parseInt(e,16);return{r:t>>16&255,g:t>>8&255,b:t&255,a:1}}if(e.length===8){let t=parseInt(e,16);return{r:t>>24&255,g:t>>16&255,b:t>>8&255,a:Math.round((t&255)/255*100)/100}}return{r:0,g:0,b:0,a:1}}function Y(o,e,t,i=1){let a=n=>{let r=Math.max(0,Math.min(255,n)).toString(16);return r.length===1?"0"+r:r},l=`#${a(o)}${a(e)}${a(t)}`;if(i<1){let n=a(Math.round(i*255));return`${l}${n}`}return l}function B(o,e,t){o/=255,e/=255,t/=255;let i=Math.max(o,e,t),a=Math.min(o,e,t),l=0,n=0,r=(i+a)/2;if(i!==a){let s=i-a;switch(n=r>.5?s/(2-i-a):s/(i+a),i){case o:l=(e-t)/s+(e<t?6:0);break;case e:l=(t-o)/s+2;break;case t:l=(o-e)/s+4;break}l/=6}return`hsl(${Math.round(l*360)}, ${Math.round(n*100)}%, ${Math.round(r*100)}%)`}function S(o){let e=o.toLowerCase().slice(0,7);for(let[t,i]of Object.entries(O))if(i.toLowerCase()===e)return t}function z(o){let e=parseFloat(o);if(isNaN(e))return o;let t=e/16;return`${Number(t.toFixed(3))}rem`}function D(o){let e=parseFloat(o);if(isNaN(e)||e===0)return"rounded-none";if(e<=2)return"rounded-sm";if(e<=4)return"rounded";if(e<=6)return"rounded-md";if(e<=8)return"rounded-lg";if(e<=12)return"rounded-xl";if(e<=16)return"rounded-2xl";if(e<=24)return"rounded-3xl";if(e>=9999||e>100)return"rounded-full"}var k=[{label:"Text Color",cssProp:"color",category:"color",type:"color"},{label:"Background",cssProp:"background-color",category:"color",type:"color"},{label:"Border Color",cssProp:"border-color",category:"color",type:"color"},{label:"Font Size",cssProp:"font-size",category:"typography",type:"text",placeholder:"16px"},{label:"Font Weight",cssProp:"font-weight",category:"typography",type:"select",options:["100","200","300","400","500","600","700","800","900"]},{label:"Line Height",cssProp:"line-height",category:"typography",type:"text",placeholder:"1.5 or 24px"},{label:"Letter Spacing",cssProp:"letter-spacing",category:"typography",type:"text",placeholder:"0px"},{label:"Width",cssProp:"width",category:"dimensions",type:"text",placeholder:"auto or 200px"},{label:"Height",cssProp:"height",category:"dimensions",type:"text",placeholder:"auto or 44px"},{label:"Gap",cssProp:"gap",category:"dimensions",type:"text",placeholder:"8px or 1rem"},{label:"Display",cssProp:"display",category:"dimensions",type:"select",options:["block","flex","inline-flex","grid","inline-block","inline","none"]},{label:"Padding",cssProp:"padding",category:"spacing",type:"text",placeholder:"8px 16px"},{label:"Margin",cssProp:"margin",category:"spacing",type:"text",placeholder:"0px auto"},{label:"Border Radius",cssProp:"border-radius",category:"style",type:"text",placeholder:"8px or 9999px"},{label:"Border",cssProp:"border",category:"style",type:"text",placeholder:"1px solid #3b82f6"},{label:"Opacity",cssProp:"opacity",category:"style",type:"text",placeholder:"1 or 0.8"}],T=class{card;isPinned=!1;activeTab="inspect";currentData=null;currentTarget=null;onCopyCallback;onElementModified;onCloseCallback;userHasMovedCard=!1;currentCorner="bottom-right";originalStyles=new Map;originalInlineStyles=new Map;styleChanges=new Map;isDragging=!1;dragStartX=0;dragStartY=0;cardStartX=0;cardStartY=0;constructor(e,t,i,a){this.onCopyCallback=t,this.onElementModified=i,this.onCloseCallback=a,this.card=document.createElement("div"),this.card.className="ib-tooltip-card",this.card.style.display="none",e.appendChild(this.card),this.initCardDragging(),this.applyCornerPosition(this.currentCorner)}getPinned(){return this.isPinned}setPinned(e){this.isPinned=e,this.card.classList.toggle("ib-pinned",this.isPinned);let t=this.card.querySelector(".ib-pin-btn");t&&(t.classList.toggle("ib-active",this.isPinned),t.setAttribute("title",this.isPinned?"Locked (Click to unlock)":"Click or click element to lock"),t.textContent=this.isPinned?"\u{1F512}":"\u{1F513}")}close(){this.setPinned(!1),this.hide(!0),this.onCloseCallback&&this.onCloseCallback()}update(e,t){this.isPinned||(this.currentTarget!==t&&(this.currentTarget=t,this.captureBaselineStyles(t),this.styleChanges.clear()),this.currentData=e,this.render(),this.userHasMovedCard||this.applyCornerPosition(this.currentCorner),this.card.style.display="flex")}hide(e=!1){(e||!this.isPinned)&&(this.card.style.display="none")}togglePin(){this.setPinned(!this.isPinned)}captureBaselineStyles(e){this.originalStyles.clear(),this.originalInlineStyles.clear();let t=window.getComputedStyle(e);k.forEach(i=>{this.originalInlineStyles.set(i.cssProp,e.style.getPropertyValue(i.cssProp));let a="";i.cssProp==="color"?a=w(t.color).hex:i.cssProp==="background-color"?a=w(t.backgroundColor).hex:i.cssProp==="border-color"?a=w(t.borderColor).hex:i.cssProp==="padding"?a=A(t.paddingTop,t.paddingRight,t.paddingBottom,t.paddingLeft):i.cssProp==="margin"?a=A(t.marginTop,t.marginRight,t.marginBottom,t.marginLeft):i.cssProp==="width"?a=e.style.width||`${Math.round(e.getBoundingClientRect().width)}px`:i.cssProp==="height"?a=e.style.height||`${Math.round(e.getBoundingClientRect().height)}px`:i.cssProp==="gap"?a=t.gap&&t.gap!=="normal"?t.gap:"0px":a=t.getPropertyValue(i.cssProp)||"",this.originalStyles.set(i.cssProp,a)})}applyCornerPosition(e){this.currentCorner=e;let t=24,i=390,a=Math.min(this.card.offsetHeight||460,560),l=window.innerWidth||1200,n=window.innerHeight||800,r=l-i-t,s=n-a-t;e==="bottom-left"?(r=t,s=n-a-t):e==="top-right"?(r=l-i-t,s=t):e==="top-left"&&(r=t,s=t),this.card.style.left=`${Math.round(r)}px`,this.card.style.top=`${Math.round(s)}px`,this.card.style.right="auto",this.card.style.bottom="auto"}initCardDragging(){let e=i=>{if(!this.isDragging)return;let a=i.clientX-this.dragStartX,l=i.clientY-this.dragStartY,n=this.cardStartX+a,r=this.cardStartY+l,s=12,p=(window.innerWidth||1200)-(this.card.offsetWidth||390)-s,b=(window.innerHeight||800)-(this.card.offsetHeight||460)-s;n=Math.max(s,Math.min(p,n)),r=Math.max(s,Math.min(b,r)),this.card.style.left=`${n}px`,this.card.style.top=`${r}px`,this.userHasMovedCard=!0},t=()=>{if(!this.isDragging)return;this.isDragging=!1,window.removeEventListener("pointermove",e,{capture:!0}),window.removeEventListener("pointerup",t,{capture:!0});let i=this.card.getBoundingClientRect(),a=window.innerWidth/2,l=window.innerHeight/2,n=i.left+i.width/2>=a,r=i.top+i.height/2>=l;r&&n?this.currentCorner="bottom-right":r&&!n?this.currentCorner="bottom-left":!r&&n?this.currentCorner="top-right":this.currentCorner="top-left"};this.card.addEventListener("pointerdown",i=>{let a=i.target;if(!a.closest(".ib-card-topbar")||a.closest("button")||a.closest(".ib-topbar-actions")||i.button!==0)return;this.isDragging=!0,this.dragStartX=i.clientX,this.dragStartY=i.clientY;let l=this.card.getBoundingClientRect();this.cardStartX=l.left,this.cardStartY=l.top,window.addEventListener("pointermove",e,{capture:!0}),window.addEventListener("pointerup",t,{capture:!0}),i.preventDefault()})}render(){if(!this.currentData)return;let e=this.currentData,t=`<span class="ib-badge ib-tag-badge">&lt;${e.tagName}&gt;</span>`,i=e.id?`<span class="ib-id-badge">#${m(e.id)}</span>`:"",a=e.classList.length?`<span class="ib-meta-dim">.${e.classList.slice(0,2).map(m).join(".")} ${e.classList.length>2?`+${e.classList.length-2}`:""}</span>`:"",l=this.styleChanges.size;this.card.innerHTML=`
      <div class="ib-card-topbar">
        <div class="ib-topbar-title">
          <div class="ib-logo-dot"></div>
          <span class="ib-brand">InspectBae</span>
          ${t}
          ${i}
          ${a}
        </div>
        <div class="ib-topbar-actions">
          <button class="ib-icon-btn ib-pin-btn ${this.isPinned?"ib-active":""}" title="${this.isPinned?"Locked (Click to unlock)":"Click to lock/freeze info"}">
            ${this.isPinned?"\u{1F512}":"\u{1F513}"}
          </button>
          <button class="ib-icon-btn ib-close-btn" title="Close InspectBae (Exit Inspection)">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>

      <!-- Mode Tabs -->
      <div class="ib-mode-tabs">
        <button type="button" class="ib-tab-btn ${this.activeTab==="inspect"?"ib-tab-active":""}" data-mode="inspect">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          Inspect
        </button>
        <button type="button" class="ib-tab-btn ${this.activeTab==="custom"?"ib-tab-active":""}" data-mode="custom">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          Custom Values
          ${l>0?`<span class="ib-tab-badge">${l}</span>`:""}
        </button>
      </div>

      <!-- Scrollable Content Body -->
      <div class="ib-card-content">
        ${this.activeTab==="inspect"?this.renderInspectTab():this.renderCustomTab()}
      </div>

      <!-- Persistent Copy Toolbar Footer -->
      <div class="ib-copy-toolbar">
        <button type="button" class="ib-action-btn ib-copy-note-btn" title="Copy handover notes in Markdown format">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
          Copy Note
        </button>
        <button type="button" class="ib-action-btn ib-copy-css" title="Copy clean CSS snippet">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
          CSS
        </button>
        ${e.frameworks.tailwind.matchedClasses.length>0?`
          <button type="button" class="ib-action-btn ib-copy-tw-all" title="Copy Tailwind utility classes">
            Tailwind
          </button>
        `:""}
        <button type="button" class="ib-action-btn ib-copy-color-btn" title="Copy element colors">
          Color
        </button>
        ${e.frameworks.react?`
          <button type="button" class="ib-action-btn ib-copy-comp-btn" title="Copy React component name">
            Component
          </button>
        `:""}
      </div>
    `,this.bindEvents(),this.activeTab==="custom"&&this.bindCustomTabEvents()}renderInspectTab(){if(!this.currentData)return"";let e=this.currentData,t=e.frameworks.react?`<div class="ib-fw-pill ib-react-pill" title="React Component">
           <svg width="12" height="12" viewBox="-11.5 -10.23174 23 20.46348"><circle cx="0" cy="0" r="2.05" fill="#00d8ff"/><g stroke="#00d8ff" stroke-width="1" fill="none"><ellipse rx="11" ry="4.2"/><ellipse rx="11" ry="4.2" transform="rotate(60)"/><ellipse rx="11" ry="4.2" transform="rotate(120)"/></g></svg>
           <span>${m(e.frameworks.react.componentName)}</span>
         </div>`:"",i=e.frameworks.radix?`<div class="ib-fw-pill ib-radix-pill" title="Radix UI Primitive">
           <span class="ib-pill-dot" style="background:#8e4ec6;"></span>
           <span>Radix: ${m(e.frameworks.radix.primitive)}</span>
           ${e.frameworks.radix.state?`<span class="ib-pill-state">[${m(e.frameworks.radix.state)}]</span>`:""}
         </div>`:"",a=e.frameworks.tailwind.matchedClasses.length>0?`<div class="ib-fw-pill ib-tw-pill" title="Tailwind CSS">
           <svg width="12" height="12" viewBox="0 0 24 24" fill="#38bdf8"><path d="M12.001,4.8c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c0.913,0.228,1.565,0.89,2.288,1.624 C13.666,10.618,15.027,12,18.001,12c3.2,0,5.2-1.6,6-4.8c-1.2,1.6-2.6,2.2-4.2,1.8c-0.913-0.228-1.565-0.89-2.288-1.624 C16.337,6.182,14.976,4.8,12.001,4.8z M6.001,12c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c0.913,0.228,1.565,0.89,2.288,1.624 c1.177,1.194,2.538,2.576,5.512,2.576c3.2,0,5.2-1.6,6-4.8c-1.2,1.6-2.6,2.2-4.2,1.8c-0.913-0.228-1.565-0.89-2.288-1.624 C10.337,13.382,8.976,12,6.001,12z"/></svg>
           <span>${e.frameworks.tailwind.matchedClasses.length} Tailwind utilities</span>
         </div>`:"",l=R("BG",e.styling.backgroundColor),n=R("Text",e.typography.color),r=e.boxModel.margin,s=e.boxModel.padding,p="";e.frameworks.cssVariables.length>0&&(p=`
        <div class="ib-section">
          <div class="ib-section-header">
            <span>CSS Variables & Tokens</span>
            <span class="ib-count">${e.frameworks.cssVariables.length}</span>
          </div>
          <div class="ib-vars-grid">
            ${e.frameworks.cssVariables.map(f=>`
              <div class="ib-var-item" data-copy="var(${m(f.variableName)})">
                <span class="ib-var-name" title="${m(f.variableName)}">${m(f.variableName)}</span>
                <span class="ib-var-val" title="${m(f.computedValue)}">${m(f.computedValue)}</span>
              </div>
            `).join("")}
          </div>
        </div>
      `);let b="";if(e.frameworks.tailwind.matchedClasses.length>0){let f=e.frameworks.tailwind.matchedClasses.slice(0,14),c=e.frameworks.tailwind.matchedClasses.length-f.length;b=`
        <div class="ib-section">
          <div class="ib-section-header">
            <span>Tailwind Classes</span>
            <button class="ib-btn-subtle ib-copy-tw-btn">Copy All</button>
          </div>
          <div class="ib-pills-wrap">
            ${f.map(u=>`<span class="ib-tw-badge" data-copy="${m(u)}">${m(u)}</span>`).join("")}
            ${c>0?`<span class="ib-more-badge">+${c} more</span>`:""}
          </div>
        </div>
      `}return`
      <!-- Framework Badges -->
      ${t||i||a?`
        <div class="ib-fw-bar">
          ${t}
          ${i}
          ${a}
        </div>
      `:""}

      <!-- Dimensions Strip -->
      <div class="ib-dim-strip">
        <div class="ib-dim-item">
          <span class="ib-dim-label">Dimensions</span>
          <span class="ib-dim-val">${e.rect.width} \xD7 ${e.rect.height} px</span>
        </div>
        <div class="ib-dim-item">
          <span class="ib-dim-label">Display</span>
          <span class="ib-dim-val">${e.styling.display}</span>
        </div>
        <div class="ib-dim-item">
          <span class="ib-dim-label">Position</span>
          <span class="ib-dim-val">${e.styling.position}</span>
        </div>
      </div>

      <!-- Typography -->
      <div class="ib-section">
        <div class="ib-section-header">
          <span>Typography</span>
          <button class="ib-btn-subtle ib-copy-font-btn">Copy Font</button>
        </div>
        <div class="ib-grid-2col">
          <div class="ib-prop-row">
            <span class="ib-prop-key">Family</span>
            <span class="ib-prop-val ib-font-name" title="${m(e.typography.fontFamily)}">
              ${m(e.typography.detectedFontName)}
              ${e.typography.isWebFont?'<span class="ib-webfont-tag">webfont</span>':""}
            </span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Size / Weight</span>
            <span class="ib-prop-val">${e.typography.fontSize} / ${e.typography.fontWeight}</span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Line Height</span>
            <span class="ib-prop-val">${e.typography.lineHeight}</span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Color</span>
            <span class="ib-prop-val">${n}</span>
          </div>
        </div>
      </div>

      <!-- Box Model Visualizer -->
      <div class="ib-section">
        <div class="ib-section-header">
          <span>Box Model (m / p)</span>
        </div>
        <div class="ib-mini-boxmodel">
          <div class="ib-bm-margin" title="Margin: ${r.top} ${r.right} ${r.bottom} ${r.left}">
            <span class="ib-bm-label">M: ${r.top} ${r.right} ${r.bottom} ${r.left}</span>
            <div class="ib-bm-padding" title="Padding: ${s.top} ${s.right} ${s.bottom} ${s.left}">
              <span class="ib-bm-label">P: ${s.top} ${s.right} ${s.bottom} ${s.left}</span>
              <div class="ib-bm-content">${e.rect.width} \xD7 ${e.rect.height}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Styling & Effects -->
      <div class="ib-section">
        <div class="ib-section-header">
          <span>Styling & Effects</span>
        </div>
        <div class="ib-grid-2col">
          <div class="ib-prop-row">
            <span class="ib-prop-key">Background</span>
            <span class="ib-prop-val">${l}</span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Border Radius</span>
            <span class="ib-prop-val">${e.styling.borderRadius.value} ${e.styling.borderRadius.tailwindMatch?`<span class="ib-tw-mini-tag">${e.styling.borderRadius.tailwindMatch}</span>`:""}</span>
          </div>
          ${e.styling.border!=="none"?`
            <div class="ib-prop-row ib-col-span-2">
              <span class="ib-prop-key">Border</span>
              <span class="ib-prop-val ib-truncate" title="${m(e.styling.border)}">${m(e.styling.border)}</span>
            </div>
          `:""}
          ${e.styling.boxShadow!=="none"?`
            <div class="ib-prop-row ib-col-span-2">
              <span class="ib-prop-key">Shadow</span>
              <span class="ib-prop-val ib-truncate" title="${m(e.styling.boxShadow)}">${m(e.styling.boxShadow)}</span>
            </div>
          `:""}
        </div>
      </div>

      <!-- Tailwind Section -->
      ${b}

      <!-- CSS Variables Section -->
      ${p}
    `}renderCustomTab(){let e=this.styleChanges.size,t=s=>{let p=this.styleChanges.has(s.cssProp),b=p?this.styleChanges.get(s.cssProp).current:this.originalStyles.get(s.cssProp)||"",f="";if(s.type==="color"){let c=H(b);f=`
          <div class="ib-color-picker-row">
            <input type="color" class="ib-color-input-native" data-color-sync="${s.cssProp}" value="${c}" />
            <input type="text" class="ib-input ${p?"ib-input-changed":""}" data-prop="${s.cssProp}" value="${m(b)}" placeholder="#rrggbb or rgb()" />
          </div>
        `}else s.type==="select"?f=`
          <select class="ib-select ${p?"ib-input-changed":""}" data-prop="${s.cssProp}">
            ${s.options?.map(c=>`<option value="${c}" ${c===b?"selected":""}>${c}</option>`).join("")}
          </select>
        `:f=`
          <input type="text" class="ib-input ${p?"ib-input-changed":""}" data-prop="${s.cssProp}" value="${m(b)}" placeholder="${s.placeholder||""}" />
        `;return`
        <div class="ib-field-group">
          <label class="ib-field-label">
            <span>${s.label}</span>
            ${p?'<span class="ib-changed-dot" title="Modified value"></span>':""}
          </label>
          ${f}
        </div>
      `},i=k.filter(s=>s.category==="color").map(t).join(""),a=k.filter(s=>s.category==="typography").map(t).join(""),l=k.filter(s=>s.category==="dimensions").map(t).join(""),n=k.filter(s=>s.category==="spacing").map(t).join(""),r=k.filter(s=>s.category==="style").map(t).join("");return`
      <div class="ib-custom-container">
        <!-- Status Bar -->
        <div class="ib-custom-status-bar">
          <div class="ib-custom-status-text">
            <span class="ib-live-indicator"></span>
            <span>Live Edit Active ${e>0?`(${e} tweaked)`:""}</span>
          </div>
          ${e>0?`
            <button type="button" class="ib-btn-reset-all" title="Revert all tweaked styles to baseline">
              \u21BA Reset All
            </button>
          `:""}
        </div>

        <!-- Colors -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Colors</span>
          <div class="ib-custom-grid">
            ${i}
          </div>
        </div>

        <!-- Typography -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Typography</span>
          <div class="ib-custom-grid">
            ${a}
          </div>
        </div>

        <!-- Layout & Size -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Dimensions & Layout</span>
          <div class="ib-custom-grid">
            ${l}
          </div>
        </div>

        <!-- Spacing -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Spacing (Padding & Margin)</span>
          <div class="ib-custom-grid">
            ${n}
          </div>
        </div>

        <!-- Borders & Effects -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Borders & Effects</span>
          <div class="ib-custom-grid">
            ${r}
          </div>
        </div>
      </div>
    `}bindEvents(){if(!this.currentData)return;let e=this.currentData;this.card.querySelector(".ib-pin-btn")?.addEventListener("click",c=>{c.stopPropagation(),this.togglePin()}),this.card.querySelector(".ib-close-btn")?.addEventListener("click",c=>{c.stopPropagation(),this.close()}),this.card.querySelectorAll(".ib-tab-btn").forEach(c=>{c.addEventListener("click",u=>{u.stopPropagation();let y=c.getAttribute("data-mode");y&&y!==this.activeTab&&(this.activeTab=y,y==="custom"&&this.setPinned(!0),this.render())})}),this.card.querySelector(".ib-copy-font-btn")?.addEventListener("click",c=>{c.stopPropagation();let u=`font-family: ${e.typography.fontFamily};
font-size: ${e.typography.fontSize};
font-weight: ${e.typography.fontWeight};`;this.copy(u,"Font properties copied")}),this.card.querySelectorAll(".ib-copy-tw-btn, .ib-copy-tw-all").forEach(c=>{c.addEventListener("click",u=>{u.stopPropagation(),this.copy(e.frameworks.tailwind.matchedClasses.join(" "),"Tailwind classes copied")})}),this.card.querySelectorAll("[data-copy]").forEach(c=>{c.addEventListener("click",u=>{u.stopPropagation();let y=c.getAttribute("data-copy");y&&this.copy(y,`Copied "${y}"`)})}),this.card.querySelector(".ib-copy-note-btn")?.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();let u=this.generateMarkdownNote();this.copy(u,"Handover Note (Markdown) copied!")}),this.card.querySelector(".ib-copy-css")?.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();let u=[`/* <${e.tagName}> styles */`,`width: ${e.rect.width}px;`,`height: ${e.rect.height}px;`,`font-family: ${e.typography.fontFamily};`,`font-size: ${e.typography.fontSize};`,`font-weight: ${e.typography.fontWeight};`,`color: ${e.typography.color.hex};`,e.styling.backgroundColor.hex!=="transparent"?`background-color: ${e.styling.backgroundColor.hex};`:"",e.styling.borderRadius.value!=="0px"?`border-radius: ${e.styling.borderRadius.value};`:"",e.styling.border!=="none"?`border: ${e.styling.border};`:"",e.styling.boxShadow!=="none"?`box-shadow: ${e.styling.boxShadow};`:"",`padding: ${e.boxModel.padding.top}px ${e.boxModel.padding.right}px ${e.boxModel.padding.bottom}px ${e.boxModel.padding.left}px;`,`margin: ${e.boxModel.margin.top}px ${e.boxModel.margin.right}px ${e.boxModel.margin.bottom}px ${e.boxModel.margin.left}px;`].filter(Boolean).join(`
`);this.copy(u,"CSS snippet copied")}),this.card.querySelector(".ib-copy-color-btn")?.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation();let u=e.styling.backgroundColor.hex!=="transparent"?e.styling.backgroundColor.hex:e.typography.color.hex;this.copy(u,`Color ${u} copied`)}),this.card.querySelector(".ib-copy-comp-btn")?.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation(),e.frameworks.react&&this.copy(e.frameworks.react.componentName,`Component <${e.frameworks.react.componentName}> copied`)})}bindCustomTabEvents(){this.card.querySelector(".ib-btn-reset-all")?.addEventListener("click",a=>{a.stopPropagation(),this.resetAllChanges()}),this.card.querySelectorAll("[data-prop]").forEach(a=>{let l=a.getAttribute("data-prop");if(!l)return;let n=()=>{this.applyLiveStyle(l,a.value);let r=this.card.querySelector(`[data-color-sync="${l}"]`);if(r){let s=H(a.value);(s!=="#000000"||a.value.toLowerCase()==="#000000"||a.value.toLowerCase()==="black")&&(r.value=s)}};a.addEventListener("input",n),a.addEventListener("change",n)}),this.card.querySelectorAll("[data-color-sync]").forEach(a=>{let l=a.getAttribute("data-color-sync");if(!l)return;let n=()=>{let r=this.card.querySelector(`input[data-prop="${l}"]`);r&&(r.value=a.value),this.applyLiveStyle(l,a.value)};a.addEventListener("input",n),a.addEventListener("change",n)})}applyLiveStyle(e,t){if(!this.currentTarget)return;let i=t.trim(),a=this.originalStyles.get(e)??"";if(i===""||i===a){let l=this.originalInlineStyles.get(e);l?this.currentTarget.style.setProperty(e,l):this.currentTarget.style.removeProperty(e),this.styleChanges.delete(e)}else{this.currentTarget.style.setProperty(e,i,"important");let l=k.find(n=>n.cssProp===e);this.styleChanges.set(e,{label:l?l.label:e,cssProp:e,original:a||"initial",current:i})}if(this.updateVisualChangeIndicators(e),this.onElementModified)try{this.onElementModified(this.currentTarget)}catch(l){console.error("[InspectBae] Error updating modified element:",l)}}updateVisualChangeIndicators(e){let t=this.styleChanges.has(e),i=this.card.querySelector(`[data-prop="${e}"]`);if(i){i.classList.toggle("ib-input-changed",t);let r=i.closest(".ib-field-group");if(r){let s=r.querySelector(".ib-field-label");if(s){let p=s.querySelector(".ib-changed-dot");if(t&&!p){let b=document.createElement("span");b.className="ib-changed-dot",b.title="Modified value",s.appendChild(b)}else!t&&p&&p.remove()}}}let a=this.card.querySelector('[data-mode="custom"]');if(a){let r=this.styleChanges.size,s=a.querySelector(".ib-tab-badge");r>0?(s||(s=document.createElement("span"),s.className="ib-tab-badge",a.appendChild(s)),s.textContent=`${r}`):s&&s.remove()}let l=this.card.querySelector(".ib-custom-status-text span:nth-child(2)");if(l){let r=this.styleChanges.size;l.textContent=`Live Edit Active ${r>0?`(${r} tweaked)`:""}`}let n=this.card.querySelector(".ib-custom-status-bar");if(n){let r=n.querySelector(".ib-btn-reset-all");this.styleChanges.size>0&&!r?(r=document.createElement("button"),r.setAttribute("type","button"),r.className="ib-btn-reset-all",r.setAttribute("title","Revert all tweaked styles to baseline"),r.textContent="\u21BA Reset All",r.addEventListener("click",s=>{s.stopPropagation(),this.resetAllChanges()}),n.appendChild(r)):this.styleChanges.size===0&&r&&r.remove()}}resetAllChanges(){this.currentTarget&&(this.styleChanges.forEach((e,t)=>{let i=this.originalInlineStyles.get(t);i?this.currentTarget.style.setProperty(t,i):this.currentTarget.style.removeProperty(t)}),this.styleChanges.clear(),this.render(),this.onElementModified&&this.onElementModified(this.currentTarget),this.onCopyCallback&&this.onCopyCallback("","All styles reverted to original"))}generateMarkdownNote(){if(!this.currentData||!this.currentTarget)return"";let e=this.currentData,t=Array.from(this.styleChanges.values()),i=[`<${e.tagName}>`,e.id?`#${e.id}`:"",e.classList.length?`.${e.classList.slice(0,3).map(m).join(".")}`:""].filter(Boolean).join(" "),l=new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),n=`### \u{1F4DD} Design Tweak Handover Notes

`;return n+=`**Target Element:** \`${i}\`
`,e.frameworks.react?.componentName&&(n+=`**React Component:** \`<${e.frameworks.react.componentName}>\`
`,e.frameworks.react.hierarchy&&e.frameworks.react.hierarchy.length>1&&(n+=`**Component Tree:** ${e.frameworks.react.hierarchy.map(r=>`\`<${r}>\``).join(" \u2794 ")}
`)),e.frameworks.radix?.primitive&&(n+=`**Radix UI Primitive:** \`${e.frameworks.radix.primitive}\`${e.frameworks.radix.state?` (state: \`${e.frameworks.radix.state}\`)`:""}
`),n+=`
---

`,t.length>0?(n+=`#### \u{1F504} Modified Properties (${t.length})

`,t.forEach(r=>{n+=`- **${r.label}** (\`${r.cssProp}\`): \`${r.original}\` \u2794 **\`${r.current}\`**
`}),n+=`
#### \u{1F4CB} CSS Snippet to Apply:
\`\`\`css
/* Applied to ${i} */
`,t.forEach(r=>{n+=`${r.cssProp}: ${r.current};
`}),n+="```\n"):(n+=`#### \u{1F4D0} Current Computed Specs (No custom changes made)

`,n+=`- **Dimensions:** \`${e.rect.width} \xD7 ${e.rect.height}px\`
`,n+=`- **Display / Position:** \`${e.styling.display}\` / \`${e.styling.position}\`
`,n+=`- **Font:** \`${e.typography.fontFamily}\` | \`${e.typography.fontSize}\` / \`${e.typography.fontWeight}\` | \`${e.typography.lineHeight}\`
`,n+=`- **Color:** \`${e.typography.color.hex}\`
`,n+=`- **Background:** \`${e.styling.backgroundColor.hex}\`
`,n+=`- **Padding:** \`${e.boxModel.padding.top}px ${e.boxModel.padding.right}px ${e.boxModel.padding.bottom}px ${e.boxModel.padding.left}px\`
`,n+=`- **Margin:** \`${e.boxModel.margin.top}px ${e.boxModel.margin.right}px ${e.boxModel.margin.bottom}px ${e.boxModel.margin.left}px\`
`,e.styling.borderRadius.value!=="0px"&&(n+=`- **Border Radius:** \`${e.styling.borderRadius.value}\`
`),e.styling.border!=="none"&&(n+=`- **Border:** \`${e.styling.border}\`
`)),n+=`
---
*Exported via InspectBae DevTools (${l})*
`,n}copy(e,t){if(this.onCopyCallback)try{this.onCopyCallback(e,t)}catch(i){console.error("Error invoking onCopyCallback:",i)}else navigator.clipboard&&navigator.clipboard.writeText&&navigator.clipboard.writeText(e)}destroy(){this.card.remove()}};function R(o,e){return e.hex==="transparent"?'<span class="ib-color-wrap"><span class="ib-swatch ib-swatch-trans"></span><span class="ib-color-val">transparent</span></span>':`
    <span class="ib-color-wrap" data-copy="${m(e.hex)}" title="Click to copy ${m(e.hex)}">
      <span class="ib-swatch" style="background:${m(e.hex)};"></span>
      <span class="ib-color-hex">${m(e.hex)}</span>
      ${e.tailwindClass?`<span class="ib-tw-mini-tag">${m(e.tailwindClass)}</span>`:""}
    </span>
  `}function H(o){if(!o||o==="transparent")return"#000000";let e=w(o);return e.hex&&e.hex.startsWith("#")&&e.hex.length>=7?e.hex.slice(0,7):"#000000"}function A(o,e,t,i){return o===e&&e===t&&t===i?o:o===t&&e===i?`${o} ${e}`:`${o} ${e} ${t} ${i}`}function m(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}function I(o){try{let e=o,t=null;for(let n=0;n<5&&e;n++){let s=Object.keys(e).find(p=>p.startsWith("__reactFiber$")||p.startsWith("__reactInternalInstance$"));if(s){t=e[s];break}e=e.parentElement}if(!t){let n=Object.keys(o).filter(r=>r.startsWith("__reactProps$"));if(n.length>0){let r=o[n[0]];if(r&&typeof r=="object")return{componentName:"ReactElement",propsCount:Object.keys(r).length}}return}let i=[],a=t,l="";for(;a;){let n=N(a);n&&!X(n)&&(l||(l=n),i.push(n)),a=a.return}if(l){let n=t.memoizedProps||t.pendingProps,r=n?Object.keys(n).length:void 0;return{componentName:l,hierarchy:i.slice(0,5),propsCount:r}}}catch{}}function N(o){if(!o||!o.type||typeof o.type=="string")return null;if(typeof o.type=="function")return o.type.displayName||o.type.name||"AnonymousComponent";if(typeof o.type=="object"){if(o.type.displayName)return o.type.displayName;if(o.type.render)return o.type.render.displayName||o.type.render.name||"ForwardRef";if(o.type.type)return N({type:o.type.type})}return null}function X(o){return["Fragment","Suspense","StrictMode","Provider","Consumer","Context"].includes(o)}function F(o){try{let e=o,t={},i="",a="",l="";for(let n=0;n<5&&e;n++){let r=Array.from(e.attributes),s=!1;for(let p of r){let b=p.name,f=p.value;if((b.startsWith("data-radix-")||b==="data-state"||b==="data-orientation"||b==="data-side"||b==="data-align"||b==="data-placeholder")&&(t[b]=f,s=!0),b.startsWith("data-radix-")){let c=b.replace("data-radix-","").split("-");c.length>0&&!i&&(i=c.map(u=>u.charAt(0).toUpperCase()+u.slice(1)).join(""))}b==="data-state"&&(l=f)}if(!i&&s&&(i=G(e)),i)break;e=e.parentElement}if(Object.keys(t).length>0||i)return{primitive:i||"RadixPrimitive",part:a||void 0,state:l||void 0,attributes:t}}catch{}}function G(o){let e=o.getAttribute("role"),t=o.tagName.toLowerCase(),i=o.id||"",a=o.className||"";return o.hasAttribute("data-radix-collection-item")?"CollectionItem":e==="dialog"||o.hasAttribute("data-radix-dialog-content")?"Dialog":e==="menu"||e==="menuitem"||o.hasAttribute("data-radix-dropdown-menu-trigger")?"DropdownMenu":e==="tooltip"||o.hasAttribute("data-radix-tooltip-trigger")?"Tooltip":e==="tab"||e==="tablist"||e==="tabpanel"?"Tabs":e==="switch"?"Switch":e==="checkbox"?"Checkbox":e==="combobox"?"Select / Combobox":o.hasAttribute("data-radix-accordion-item")||o.hasAttribute("data-radix-accordion-trigger")?"Accordion":o.hasAttribute("data-radix-popover-content")||o.hasAttribute("data-radix-popover-trigger")?"Popover":o.hasAttribute("data-radix-scroll-area-viewport")?"ScrollArea":o.hasAttribute("data-state")?"RadixPrimitive":""}function V(o){let e=Array.from(o.classList),t=[],i={typography:[],layout:[],spacing:[],colors:[],effects:[],borders:[],other:[]};for(let a of e)if(U(a)){t.push(a);let l=K(a);i[l].push(a)}return{matchedClasses:t,categorized:i}}function U(o){return[/^(p|px|py|pt|pr|pb|pl|m|mx|my|mt|mr|mb|ml|space-[xy]|gap|gap-[xy])-(\d+|\[.+\]|auto|px)$/,/^(flex|inline-flex|grid|inline-grid|block|inline-block|inline|hidden)$/,/^(flex-(row|row-reverse|col|col-reverse|wrap|wrap-reverse|nowrap|1|auto|initial|none))$/,/^(items|justify|content|self|place)-(start|end|center|between|around|evenly|stretch|baseline|auto)/,/^(grid-cols|grid-rows|col-span|row-span)-/,/^(w|min-w|max-w|h|min-h|max-h)-(\d+|\[.+\]|auto|full|screen|fit|min|max|px)/,/^(text|font|leading|tracking)-(xs|sm|base|lg|xl|\dxl|thin|extralight|light|normal|medium|semibold|bold|extrabold|black|tight|snug|normal|relaxed|loose|tighter|wider|widest|center|left|right|justify)/,/^(underline|line-through|no-underline|uppercase|lowercase|capitalize|italic|not-italic|truncate)/,/^(bg|text|border|ring|accent|fill|stroke)-([a-z]+-\d+|white|black|transparent|current|\[.+\])/,/^(rounded|rounded-(t|r|b|l|tl|tr|br|bl))(-[a-z0-9]+|\[.+\])?$/,/^(border|border-[trblxy])(-(\d+|\[.+\]))?$/,/^(ring|ring-offset)(-(\d+|\[.+\]))?$/,/^(shadow|shadow-(sm|md|lg|xl|2xl|inner|none)|opacity-\d+|blur|backdrop-blur|blur-[a-z0-9]+)/,/^(relative|absolute|fixed|sticky|static)$/,/^(top|right|bottom|left|inset|inset-[xy])-(\d+|auto|full|px|\[.+\])/,/^(z)-(\d+|auto|\[.+\])/,/^(transition|duration-\d+|ease-[a-z]+|scale-\d+|rotate-\d+|translate-[xy]-\d+)/,/^(overflow|overflow-[xy])-(auto|hidden|clip|visible|scroll)/,/^(cursor)-(pointer|default|not-allowed|text|move)/].some(t=>t.test(o))}function K(o){return/^(text|font|leading|tracking|underline|italic|truncate|uppercase|lowercase)/.test(o)?"typography":/^(p|px|py|pt|pr|pb|pl|m|mx|my|mt|mr|mb|ml|space|gap)/.test(o)?"spacing":/^(bg|text|border)-([a-z]+-\d+|white|black|transparent)/.test(o)?"colors":/^(rounded|border|ring)/.test(o)?"borders":/^(shadow|opacity|blur|backdrop)/.test(o)?"effects":/^(flex|grid|block|inline|items|justify|w-|h-|min-|max-|relative|absolute|fixed|sticky|overflow)/.test(o)?"layout":"other"}function j(o,e){let t=[],i=["background-color","color","border-color","border-radius","font-family","font-size","gap","padding","margin","box-shadow","fill","stroke"];for(let a=0;a<o.style.length;a++){let l=o.style[a],r=o.style.getPropertyValue(l).match(/var\((--[a-zA-Z0-9-_]+)\)/g);if(r)for(let s of r){let p=s.replace(/var\(|\)/g,"").trim(),b=e.getPropertyValue(p).trim();t.push({property:l,variableName:p,computedValue:b||e.getPropertyValue(l)})}}try{let a=getComputedStyle(document.documentElement),l=["--tw-","--ds-","--color-","--primary","--secondary","--background","--foreground","--radius","--font-","--space-","--shadow-"],n=new Map;for(let r of Array.from(document.styleSheets))try{let s=r.cssRules||r.rules;if(!s)continue;for(let p of Array.from(s))if(p instanceof CSSStyleRule){let b=!1;try{(p.selectorText===":root"||p.selectorText==="html"||p.selectorText==="body"||o.matches(p.selectorText))&&(b=!0)}catch{}if(b){let f=p.style;for(let c=0;c<f.length;c++){let u=f[c];if(u.startsWith("--")){let y=f.getPropertyValue(u).trim();n.set(u,y)}}}}}catch{}for(let r of i){let s=e.getPropertyValue(r).trim();if(s)for(let[p,b]of n.entries()){let f=e.getPropertyValue(p).trim()||a.getPropertyValue(p).trim();f&&(f===s||s.includes(f)&&f.length>3)&&(t.some(c=>c.variableName===p&&c.property===r)||t.push({property:r,variableName:p,computedValue:s}))}}}catch{}return t.slice(0,10)}function P(o){let e=window.getComputedStyle(o),t=o.getBoundingClientRect(),i=v=>{let E=parseFloat(v);return isNaN(E)?0:Math.round(E)},a={margin:{top:i(e.marginTop),right:i(e.marginRight),bottom:i(e.marginBottom),left:i(e.marginLeft)},padding:{top:i(e.paddingTop),right:i(e.paddingRight),bottom:i(e.paddingBottom),left:i(e.paddingLeft)},border:{top:i(e.borderTopWidth),right:i(e.borderRightWidth),bottom:i(e.borderBottomWidth),left:i(e.borderLeftWidth)}},l=e.fontFamily||"",n=l.split(",")[0].replace(/['"]/g,"").trim(),r=Z(n),s=w(e.color,o,"color"),p=w(e.backgroundColor,o,"background-color"),b=e.borderRadius,f=z(b),c=D(b),u=e.borderWidth,y=e.borderStyle,C=e.borderColor,$=u!=="0px"&&y!=="none"?`${u} ${y} ${C}`:"none",d=I(o),g=F(o),h=V(o),x=j(o,e);return{tagName:o.tagName.toLowerCase(),id:o.id||void 0,classList:Array.from(o.classList),rect:{x:Math.round(t.x),y:Math.round(t.y),width:Math.round(t.width),height:Math.round(t.height),top:Math.round(t.top),left:Math.round(t.left),bottom:Math.round(t.bottom),right:Math.round(t.right)},boxModel:a,typography:{fontFamily:l,detectedFontName:n,isWebFont:r,fontSize:e.fontSize,fontWeight:e.fontWeight,lineHeight:e.lineHeight,letterSpacing:e.letterSpacing,color:s},styling:{backgroundColor:p,border:$,borderRadius:{value:b,rem:f,tailwindMatch:c},boxShadow:e.boxShadow!=="none"?e.boxShadow:"none",opacity:e.opacity,backdropFilter:e.backdropFilter||e.webkitBackdropFilter||"none",display:e.display,position:e.position,zIndex:e.zIndex},frameworks:{react:d,radix:g,tailwind:h,cssVariables:x}}}function Z(o){return!o||["system-ui","-apple-system","BlinkMacSystemFont","Segoe UI","Roboto","Helvetica Neue","Arial","sans-serif","serif","monospace","Times New Roman","Georgia","Courier New","Verdana","Tahoma","Trebuchet MS"].map(t=>t.toLowerCase()).includes(o.toLowerCase())?!1:document.fonts&&document.fonts.check?document.fonts.check(`12px "${o}"`):!0}(function(){if(window.__INSPECT_BAE_LOADED__)return;window.__INSPECT_BAE_LOADED__=!0;let o=!1,e=null,t=null,i=null,a=null,l=null;function n(){if(t)return;t=document.createElement("div"),t.id="inspect-bae-root",t.style.position="fixed",t.style.top="0",t.style.left="0",t.style.width="0",t.style.height="0",t.style.zIndex="2147483647",t.style.pointerEvents="none",i=t.attachShadow({mode:"open"});let d=document.createElement("style");d.textContent=L,i.appendChild(d),a=new M(i),l=new T(i,c,f,()=>r(!1)),document.documentElement.appendChild(t)}function r(d){o=d!==void 0?d:!o,o?(C(),u("InspectBae: Active (Hover any element)")):($(),a&&a.hide(),l&&(l.setPinned(!1),l.hide(!0)),u("InspectBae: Closed"));try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:"STATE_UPDATE",payload:{isEnabled:o}})}catch{}}function s(d){if(!o||l&&l.getPinned())return;if(t){let h=d.composedPath?d.composedPath():[];if(h.includes(t)||i&&h.some(x=>x instanceof Node&&i.contains(x)))return}let g=d.target;if((!g||g===t||g.id==="inspect-bae-root")&&(g=document.elementFromPoint(d.clientX,d.clientY)),!(!g||g===e||g===t||g.id==="inspect-bae-root")){e=g;try{let h=P(g);a&&a.update(g,h),l&&l.update(h,g)}catch(h){console.error("[InspectBae] Error extracting element data:",h)}}}function p(d){if(o){if(t){let g=d.composedPath?d.composedPath():[];if(g.includes(t)||i&&g.some(h=>h instanceof Node&&i.contains(h)))return}if(l){let g=!l.getPinned();l.setPinned(g),u(g?"Element Locked! You can now scroll info or drag card.":"Element Unlocked. Hover to inspect another."),d.preventDefault(),d.stopPropagation()}}}function b(d){let g=document.activeElement;(d.composedPath?d.composedPath():[]).some(v=>v instanceof HTMLElement&&(v.tagName==="INPUT"||v.tagName==="TEXTAREA"||v.tagName==="SELECT"))||g&&(g.tagName==="INPUT"||g.tagName==="TEXTAREA"||g.tagName==="SELECT")||(d.key==="Escape"&&o&&r(!1),(d.key==="p"||d.key==="P")&&o&&l&&l.togglePin())}function f(d){if(!(!d||!a))try{let g=P(d);a.update(d,g)}catch(g){console.error("[InspectBae] Error updating overlay on modification:",g)}}function c(d,g){try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(d).catch(()=>{});else{let h=document.createElement("textarea");h.value=d,h.style.position="fixed",h.style.opacity="0",document.body.appendChild(h),h.select(),document.execCommand("copy"),h.remove()}}catch{}u(g)}function u(d){if(!i)return;i.querySelectorAll(".ib-toast").forEach(x=>x.remove());let h=document.createElement("div");h.className="ib-toast",h.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
      <span>${y(d)}</span>
    `,i.appendChild(h),setTimeout(()=>{h.remove()},2100)}function y(d){return d.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function C(){window.addEventListener("pointermove",s,{passive:!0,capture:!0}),window.addEventListener("mousemove",s,{passive:!0,capture:!0}),window.addEventListener("click",p,{capture:!0}),window.addEventListener("keydown",b,{capture:!0})}function $(){window.removeEventListener("pointermove",s,{capture:!0}),window.removeEventListener("mousemove",s,{capture:!0}),window.removeEventListener("click",p,{capture:!0}),window.removeEventListener("keydown",b,{capture:!0}),e=null}window.addEventListener("keydown",d=>{(d.metaKey||d.ctrlKey)&&d.shiftKey&&(d.key==="X"||d.key==="x")&&(r(),d.preventDefault())},{capture:!0}),window.addEventListener("message",d=>{d.data&&d.data.type==="INSPECT_BAE_TOGGLE"&&r(d.data.payload)}),typeof chrome<"u"&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((d,g,h)=>(d.type==="TOGGLE_INSPECTION"?(r(d.payload),h({isEnabled:o})):d.type==="GET_STATE"&&h({isEnabled:o}),!0)),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",n):n()})();})();
