"use strict";(()=>{var B=`
/* CSS Reset inside Shadow DOM */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
}

/* FAB - Floating Action Button */
.ib-fab {
  position: fixed;
  right: 24px;
  bottom: 24px;
  width: 52px;
  height: 52px;
  z-index: 2147483647;
  pointer-events: auto;
  cursor: grab;
  user-select: none;
  touch-action: none;
  border-radius: 50%;
  box-shadow: 0 8px 24px -4px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(255, 255, 255, 0.1);
  transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s;
}

.ib-fab:active {
  cursor: grabbing;
  transform: scale(0.96);
}

.ib-fab-inner {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  background: linear-gradient(135deg, #18181b 0%, #09090b 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1.5px solid #27272a;
}

.ib-fab-icon {
  color: #a1a1aa;
  transition: color 0.2s, transform 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.ib-fab:hover .ib-fab-icon {
  color: #fafafa;
  transform: rotate(15deg);
}

.ib-fab-active .ib-fab-inner {
  background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
  border-color: #818cf8;
  box-shadow: 0 0 20px rgba(99, 102, 241, 0.6);
}

.ib-fab-active .ib-fab-icon {
  color: #ffffff;
  transform: rotate(90deg);
}

.ib-fab-pulse {
  display: none;
  position: absolute;
  inset: -4px;
  border-radius: 50%;
  border: 2px solid #818cf8;
  animation: ib-pulse 1.8s infinite;
}

.ib-fab-active .ib-fab-pulse {
  display: block;
}

@keyframes ib-pulse {
  0% { transform: scale(1); opacity: 0.8; }
  100% { transform: scale(1.4); opacity: 0; }
}

/* BOX MODEL OVERLAY */
.ib-overlay-container {
  display: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 2147483645;
}

.ib-box-model {
  position: fixed;
  pointer-events: none;
  transition: top 0.05s ease-out, left 0.05s ease-out, width 0.05s ease-out, height 0.05s ease-out;
}

/* Margin Layer - Orange */
.ib-box-margin {
  background-color: rgba(246, 178, 107, 0.35);
  border: 1px dashed rgba(230, 145, 56, 0.8);
}

/* Border Layer - Yellow/Amber */
.ib-box-border {
  background-color: rgba(255, 229, 153, 0.35);
  border: 1px solid rgba(241, 194, 50, 0.85);
}

/* Padding Layer - Green */
.ib-box-padding {
  background-color: rgba(182, 215, 168, 0.4);
  border: 1px dashed rgba(106, 168, 79, 0.85);
}

/* Content Layer - Soft Blue / Cyan */
.ib-box-content {
  background-color: rgba(111, 168, 220, 0.3);
  box-shadow: 0 0 0 1.5px #3b82f6;
}

/* FLOATING TOOLTIP CARD */
.ib-tooltip-card {
  position: fixed;
  width: 390px;
  max-height: 560px;
  background: #0e0e11;
  color: #e4e4e7;
  border-radius: 14px;
  border: 1px solid #27272a;
  box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.06);
  z-index: 2147483646;
  pointer-events: auto;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  font-size: 12px;
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  transition: box-shadow 0.2s ease, border-color 0.2s ease;
  animation: ib-pop 0.16s cubic-bezier(0.16, 1, 0.3, 1);
}

.ib-pinned {
  border-color: #6366f1 !important;
  box-shadow: 0 20px 40px -10px rgba(99, 102, 241, 0.35), 0 0 0 2px #6366f1 !important;
}

.ib-card-topbar {
  cursor: grab;
}

.ib-card-topbar:active {
  cursor: grabbing;
}

/* Topbar */
.ib-card-topbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 14px;
  background: #141418;
  border-bottom: 1px solid #1f1f23;
  user-select: none;
}

.ib-topbar-title {
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ib-logo-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #6366f1;
  box-shadow: 0 0 8px #6366f1;
}

.ib-brand {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #71717a;
}

.ib-tag-badge {
  font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
  font-size: 12px;
  font-weight: 700;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.12);
  padding: 2px 6px;
  border-radius: 4px;
}

.ib-id-badge {
  font-family: ui-monospace, monospace;
  font-size: 11px;
  color: #f59e0b;
}

.ib-meta-dim {
  font-size: 11px;
  color: #71717a;
}

.ib-topbar-actions {
  display: flex;
  align-items: center;
  gap: 4px;
}

.ib-icon-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 4px;
  border-radius: 4px;
  font-size: 12px;
  opacity: 0.7;
  transition: opacity 0.15s, background-color 0.15s;
}

.ib-icon-btn:hover {
  opacity: 1;
  background: rgba(255, 255, 255, 0.08);
}

.ib-icon-btn.ib-active {
  opacity: 1;
  background: rgba(99, 102, 241, 0.25);
}

/* Card Content Body */
.ib-card-content {
  overflow-y: auto;
  max-height: 440px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ib-card-content::-webkit-scrollbar {
  width: 5px;
}
.ib-card-content::-webkit-scrollbar-thumb {
  background: #27272a;
  border-radius: 3px;
}

/* Framework Bar */
.ib-fw-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.ib-fw-pill {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 3px 8px;
  border-radius: 9999px;
  font-size: 11px;
  font-weight: 600;
}

.ib-react-pill {
  background: rgba(0, 216, 255, 0.12);
  color: #38bdf8;
  border: 1px solid rgba(0, 216, 255, 0.25);
}

.ib-radix-pill {
  background: rgba(142, 78, 198, 0.14);
  color: #c084fc;
  border: 1px solid rgba(142, 78, 198, 0.3);
}

.ib-pill-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.ib-pill-state {
  font-size: 10px;
  opacity: 0.8;
}

.ib-tw-pill {
  background: rgba(14, 165, 233, 0.12);
  color: #38bdf8;
  border: 1px solid rgba(14, 165, 233, 0.25);
}

/* Dimension Strip */
.ib-dim-strip {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 6px;
  background: #141418;
  padding: 8px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-dim-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.ib-dim-label {
  font-size: 10px;
  color: #71717a;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.ib-dim-val {
  font-size: 11px;
  font-weight: 600;
  color: #f4f4f5;
  font-family: ui-monospace, monospace;
}

/* Sections */
.ib-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ib-section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 11px;
  font-weight: 700;
  color: #a1a1aa;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.ib-count {
  background: #27272a;
  color: #d4d4d8;
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 9999px;
}

.ib-btn-subtle {
  background: none;
  border: none;
  color: #6366f1;
  cursor: pointer;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 4px;
  border-radius: 3px;
}

.ib-btn-subtle:hover {
  background: rgba(99, 102, 241, 0.12);
  color: #818cf8;
}

.ib-grid-2col {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 6px 12px;
  background: #141418;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-col-span-2 {
  grid-column: span 2;
}

.ib-prop-row {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.ib-prop-key {
  font-size: 10px;
  color: #71717a;
}

.ib-prop-val {
  font-size: 11px;
  color: #f4f4f5;
  font-family: ui-monospace, monospace;
  word-break: break-all;
}

.ib-truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ib-font-name {
  display: flex;
  align-items: center;
  gap: 4px;
}

.ib-webfont-tag {
  font-size: 9px;
  background: rgba(16, 185, 129, 0.15);
  color: #34d399;
  border: 1px solid rgba(16, 185, 129, 0.3);
  padding: 1px 4px;
  border-radius: 3px;
  font-family: sans-serif;
  text-transform: uppercase;
}

/* Color Swatches */
.ib-color-wrap {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
}

.ib-swatch {
  width: 13px;
  height: 13px;
  border-radius: 3px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  flex-shrink: 0;
}

.ib-swatch-trans {
  background: repeating-conic-gradient(#3f3f46 0% 25%, #27272a 0% 50%) 50% / 6px 6px;
}

.ib-color-hex {
  font-size: 11px;
}

.ib-tw-mini-tag {
  font-size: 9px;
  background: #27272a;
  color: #38bdf8;
  padding: 1px 4px;
  border-radius: 3px;
  font-family: ui-monospace, monospace;
}

/* Mini Box Model Visualizer */
.ib-mini-boxmodel {
  background: #141418;
  border: 1px solid #1f1f23;
  border-radius: 8px;
  padding: 8px;
  display: flex;
  justify-content: center;
}

.ib-bm-margin {
  background: rgba(246, 178, 107, 0.15);
  border: 1px dashed rgba(230, 145, 56, 0.6);
  padding: 6px;
  border-radius: 6px;
  text-align: center;
  width: 100%;
}

.ib-bm-padding {
  background: rgba(182, 215, 168, 0.2);
  border: 1px dashed rgba(106, 168, 79, 0.6);
  padding: 6px;
  border-radius: 4px;
  margin-top: 4px;
}

.ib-bm-content {
  background: rgba(111, 168, 220, 0.25);
  border: 1px solid #3b82f6;
  border-radius: 3px;
  padding: 4px 0;
  font-size: 10px;
  font-family: ui-monospace, monospace;
  color: #93c5fd;
  font-weight: 600;
  margin-top: 4px;
}

.ib-bm-label {
  font-size: 9px;
  font-family: ui-monospace, monospace;
  color: #a1a1aa;
}

/* Tailwind Pills */
.ib-pills-wrap {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  background: #141418;
  padding: 8px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-tw-badge {
  font-family: ui-monospace, monospace;
  font-size: 11px;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.1);
  border: 1px solid rgba(56, 189, 248, 0.2);
  padding: 2px 6px;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.15s, color 0.15s;
}

.ib-tw-badge:hover {
  background: rgba(56, 189, 248, 0.25);
  color: #ffffff;
}

.ib-more-badge {
  font-size: 10px;
  color: #71717a;
  padding: 2px 4px;
  align-self: center;
}

/* CSS Variables Grid */
.ib-vars-grid {
  display: flex;
  flex-direction: column;
  gap: 4px;
  background: #141418;
  padding: 8px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-var-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-family: ui-monospace, monospace;
  font-size: 10.5px;
  padding: 3px 6px;
  border-radius: 4px;
  background: rgba(255, 255, 255, 0.02);
  cursor: pointer;
}

.ib-var-item:hover {
  background: rgba(99, 102, 241, 0.15);
}

.ib-var-name {
  color: #c084fc;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 55%;
}

.ib-var-val {
  color: #94a3b8;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 40%;
}

/* Copy Toolbar */
.ib-copy-toolbar {
  display: flex;
  gap: 6px;
  padding: 10px 14px;
  background: #141418;
  border-top: 1px solid #1f1f23;
  flex-shrink: 0;
}

/* Mode Tabs */
.ib-mode-tabs {
  display: flex;
  background: #141418;
  border-bottom: 1px solid #1f1f23;
  padding: 4px 10px;
  gap: 6px;
  flex-shrink: 0;
}

.ib-tab-btn {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  padding: 6px 10px;
  background: transparent;
  border: none;
  border-radius: 6px;
  color: #a1a1aa;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}

.ib-tab-btn:hover {
  color: #fafafa;
  background: rgba(255, 255, 255, 0.05);
}

.ib-tab-btn.ib-tab-active {
  color: #ffffff;
  background: #27272a;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
}

.ib-tab-badge {
  background: #6366f1;
  color: #ffffff;
  font-size: 9px;
  font-weight: 700;
  padding: 1px 5px;
  border-radius: 9999px;
  line-height: 1;
}

/* Custom Values Editor */
.ib-custom-container {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.ib-custom-status-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: #141418;
  padding: 8px 10px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-custom-status-text {
  font-size: 11px;
  color: #a1a1aa;
  display: flex;
  align-items: center;
  gap: 6px;
}

.ib-live-indicator {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #10b981;
  box-shadow: 0 0 6px #10b981;
}

.ib-btn-reset-all {
  background: transparent;
  border: 1px solid rgba(244, 63, 94, 0.4);
  color: #fb7185;
  font-size: 10px;
  font-weight: 600;
  padding: 3px 8px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.ib-btn-reset-all:hover {
  background: rgba(244, 63, 94, 0.15);
  border-color: #f43f5e;
  color: #ffffff;
}

.ib-custom-section {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.ib-custom-sec-title {
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #71717a;
  padding-left: 2px;
}

.ib-custom-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  background: #141418;
  padding: 10px;
  border-radius: 8px;
  border: 1px solid #1f1f23;
}

.ib-field-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
}

.ib-field-group.ib-col-span-2 {
  grid-column: span 2;
}

.ib-field-label {
  font-size: 10px;
  color: #858592;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 500;
}

.ib-changed-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #818cf8;
  box-shadow: 0 0 6px #818cf8;
  display: inline-block;
}

.ib-input {
  background: #09090b;
  border: 1px solid #27272a;
  border-radius: 6px;
  color: #fafafa;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 6px 8px;
  width: 100%;
  outline: none;
  transition: border-color 0.15s, box-shadow 0.15s, background-color 0.15s;
}

.ib-input:focus {
  border-color: #6366f1;
  box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2);
}

.ib-input.ib-input-changed {
  border-color: #6366f1;
  background: rgba(99, 102, 241, 0.08);
}

.ib-color-picker-row {
  display: flex;
  align-items: center;
  gap: 6px;
}

.ib-color-input-native {
  -webkit-appearance: none;
  border: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  cursor: pointer;
  background: transparent;
  padding: 0;
  flex-shrink: 0;
}

.ib-color-input-native::-webkit-color-swatch-wrapper {
  padding: 0;
}

.ib-color-input-native::-webkit-color-swatch {
  border: 1px solid #3f3f46;
  border-radius: 5px;
}

.ib-select {
  background: #09090b;
  border: 1px solid #27272a;
  border-radius: 6px;
  color: #fafafa;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 6px 8px;
  width: 100%;
  outline: none;
  cursor: pointer;
}

.ib-select:focus {
  border-color: #6366f1;
}

.ib-select.ib-input-changed {
  border-color: #6366f1;
  background: rgba(99, 102, 241, 0.08);
}

.ib-copy-note-btn {
  background: #4f46e5 !important;
  color: #ffffff !important;
  border-color: #6366f1 !important;
  font-weight: 700 !important;
}

.ib-copy-note-btn:hover {
  background: #4338ca !important;
  box-shadow: 0 0 12px rgba(99, 102, 241, 0.4) !important;
}

.ib-action-btn {
  flex: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  background: #1c1c21;
  color: #d4d4d8;
  border: 1px solid #2e2e34;
  padding: 6px 10px;
  border-radius: 6px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.15s ease;
}

.ib-action-btn:hover {
  background: #27272a;
  color: #ffffff;
  border-color: #3f3f46;
}

.ib-action-btn:active {
  transform: scale(0.98);
}

/* Toast Notification */
.ib-toast {
  position: fixed;
  bottom: 84px;
  right: 24px;
  background: #10b981;
  color: #ffffff;
  font-size: 12px;
  font-weight: 600;
  padding: 8px 14px;
  border-radius: 8px;
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
  z-index: 2147483647;
  pointer-events: auto;
  display: flex;
  align-items: center;
  gap: 6px;
  animation: ib-toast-anim 2s forwards;
}

@keyframes ib-toast-anim {
  0% { opacity: 0; transform: translateY(10px); }
  15% { opacity: 1; transform: translateY(0); }
  85% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-8px); }
}
`;var M=class{fab;isInspectionActive=!1;isDragging=!1;hasMoved=!1;startX=0;startY=0;initialLeft=0;initialTop=0;onToggleCallback;constructor(t,e){this.onToggleCallback=e,this.fab=document.createElement("div"),this.fab.className="ib-fab",this.fab.title="InspectBae: Click to Toggle Inspection, Drag to reposition",this.fab.innerHTML=`
      <div class="ib-fab-inner">
        <div class="ib-fab-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="22" y1="12" x2="18" y2="12"></line>
            <line x1="6" y1="12" x2="2" y2="12"></line>
            <line x1="12" y1="6" x2="12" y2="2"></line>
            <line x1="12" y1="22" x2="12" y2="18"></line>
          </svg>
        </div>
        <div class="ib-fab-pulse"></div>
      </div>
    `,t.appendChild(this.fab),this.initEvents()}setActive(t){this.isInspectionActive=t,this.fab.classList.toggle("ib-fab-active",t)}initEvents(){let t=n=>{if(n.button!==0)return;this.isDragging=!0,this.hasMoved=!1,this.startX=n.clientX,this.startY=n.clientY;let l=this.fab.getBoundingClientRect();this.initialLeft=l.left,this.initialTop=l.top,document.addEventListener("pointermove",e,{capture:!0}),document.addEventListener("pointerup",i,{capture:!0}),window.addEventListener("pointermove",e,{capture:!0}),window.addEventListener("pointerup",i,{capture:!0}),n.preventDefault()},e=n=>{if(!this.isDragging)return;let l=n.clientX-this.startX,a=n.clientY-this.startY;(Math.abs(l)>3||Math.abs(a)>3)&&(this.hasMoved=!0);let r=this.initialLeft+l,s=this.initialTop+a,c=12,p=(window.innerWidth||1e3)-(this.fab.offsetWidth||52)-c,d=(window.innerHeight||800)-(this.fab.offsetHeight||52)-c;r=Math.max(c,Math.min(p,r)),s=Math.max(c,Math.min(d,s)),this.fab.style.left=`${r}px`,this.fab.style.top=`${s}px`,this.fab.style.right="auto",this.fab.style.bottom="auto"},i=n=>{this.isDragging&&(this.isDragging=!1,document.removeEventListener("pointermove",e,{capture:!0}),document.removeEventListener("pointerup",i,{capture:!0}),window.removeEventListener("pointermove",e,{capture:!0}),window.removeEventListener("pointerup",i,{capture:!0}),this.hasMoved?this.snapToCorner():this.toggle())};this.fab.addEventListener("pointerdown",t),this.fab.addEventListener("click",n=>{n.stopPropagation(),this.hasMoved||this.toggle()})}snapToCorner(){let e=this.fab.getBoundingClientRect(),i=window.innerWidth/2,n=window.innerHeight/2,l=e.left+e.width/2>=i,a=e.top+e.height/2>=n,r=l?window.innerWidth-(this.fab.offsetWidth||52)-24:24,s=a?window.innerHeight-(this.fab.offsetHeight||52)-24:24;this.fab.style.transition="left 0.25s cubic-bezier(0.16, 1, 0.3, 1), top 0.25s cubic-bezier(0.16, 1, 0.3, 1)",this.fab.style.left=`${r}px`,this.fab.style.top=`${s}px`,setTimeout(()=>{this.fab.style.transition=""},260)}toggle(){this.isInspectionActive=!this.isInspectionActive,this.setActive(this.isInspectionActive),this.onToggleCallback(this.isInspectionActive)}destroy(){this.fab.remove()}};var T=class{container;marginEl;borderEl;paddingEl;contentEl;constructor(t){this.container=document.createElement("div"),this.container.className="ib-overlay-container",this.marginEl=document.createElement("div"),this.marginEl.className="ib-box-model ib-box-margin",this.borderEl=document.createElement("div"),this.borderEl.className="ib-box-model ib-box-border",this.paddingEl=document.createElement("div"),this.paddingEl.className="ib-box-model ib-box-padding",this.contentEl=document.createElement("div"),this.contentEl.className="ib-box-model ib-box-content",this.container.appendChild(this.marginEl),this.container.appendChild(this.borderEl),this.container.appendChild(this.paddingEl),this.container.appendChild(this.contentEl),t.appendChild(this.container)}update(t,e){let i=t.getBoundingClientRect(),{margin:n,padding:l,border:a}=e.boxModel,r=window.scrollX,s=window.scrollY,c=i.top+a.top+l.top,p=i.left+a.left+l.left,d=Math.max(0,i.width-a.left-a.right-l.left-l.right),f=Math.max(0,i.height-a.top-a.bottom-l.top-l.bottom),m=i.top+a.top,y=i.left+a.left,$=Math.max(0,i.width-a.left-a.right),C=Math.max(0,i.height-a.top-a.bottom),E=i.top,b=i.left,g=i.width,u=i.height,x=i.top-n.top,v=i.left-n.left,Y=i.width+n.left+n.right,_=i.height+n.top+n.bottom;this.applyBox(this.marginEl,x,v,Y,_),this.applyBox(this.borderEl,E,b,g,u),this.applyBox(this.paddingEl,m,y,$,C),this.applyBox(this.contentEl,c,p,d,f),this.container.style.display="block"}applyBox(t,e,i,n,l){t.style.top=`${e}px`,t.style.left=`${i}px`,t.style.width=`${n}px`,t.style.height=`${l}px`}hide(){this.container.style.display="none"}destroy(){this.container.remove()}};var O={"slate-50":"#f8fafc","slate-100":"#f1f5f9","slate-200":"#e2e8f0","slate-300":"#cbd5e1","slate-400":"#94a3b8","slate-500":"#64748b","slate-600":"#475569","slate-700":"#334155","slate-800":"#1e293b","slate-900":"#0f172a","slate-950":"#020617","gray-50":"#f9fafb","gray-100":"#f3f4f6","gray-200":"#e5e7eb","gray-300":"#d1d5db","gray-400":"#9ca3af","gray-500":"#6b7280","gray-600":"#4b5563","gray-700":"#374151","gray-800":"#1f2937","gray-900":"#111827","gray-950":"#030712","zinc-50":"#fafafa","zinc-100":"#f4f4f5","zinc-200":"#e4e4e7","zinc-300":"#d4d4d8","zinc-400":"#a1a1aa","zinc-500":"#71717a","zinc-600":"#52525b","zinc-700":"#3f3f46","zinc-800":"#27272a","zinc-900":"#18181b","zinc-950":"#09090b","neutral-50":"#fafafa","neutral-100":"#f5f5f5","neutral-200":"#e5e5e5","neutral-300":"#d4d4d4","neutral-400":"#a3a3a3","neutral-500":"#737373","neutral-600":"#525252","neutral-700":"#404040","neutral-800":"#262626","neutral-900":"#171717","neutral-950":"#0a0a0a","red-50":"#fef2f2","red-100":"#fee2e2","red-200":"#fecaca","red-300":"#fca5a5","red-400":"#f87171","red-500":"#ef4444","red-600":"#dc2626","red-700":"#b91c1c","red-800":"#991b1b","red-900":"#7f1d1d","red-950":"#450a0a","orange-50":"#fff7ed","orange-100":"#ffedd5","orange-200":"#fed7aa","orange-300":"#fdba74","orange-400":"#fb923c","orange-500":"#f97316","orange-600":"#ea580c","orange-700":"#c2410c","orange-800":"#9a3412","orange-900":"#7c2d12","orange-950":"#431407","amber-50":"#fffbeb","amber-100":"#fef3c7","amber-200":"#fde68a","amber-300":"#fcd34d","amber-400":"#fbbf24","amber-500":"#f59e0b","amber-600":"#d97706","amber-700":"#b45309","amber-800":"#92400e","amber-900":"#78350f","amber-950":"#451a03","yellow-50":"#fefce8","yellow-100":"#fef9c3","yellow-200":"#fef08a","yellow-300":"#fde047","yellow-400":"#facc15","yellow-500":"#eab308","yellow-600":"#ca8a04","yellow-700":"#a16207","yellow-800":"#854d0e","yellow-900":"#713f12","yellow-950":"#422006","green-50":"#f0fdf4","green-100":"#dcfce7","green-200":"#bbf7d0","green-300":"#86efac","green-400":"#4ade80","green-500":"#22c55e","green-600":"#16a34a","green-700":"#15803d","green-800":"#166534","green-900":"#14532d","green-950":"#052e16","emerald-50":"#ecfdf5","emerald-100":"#d1fae5","emerald-200":"#a7f3d0","emerald-300":"#6ee7b7","emerald-400":"#34d399","emerald-500":"#10b981","emerald-600":"#059669","emerald-700":"#047857","emerald-800":"#065f46","emerald-900":"#064e3b","emerald-950":"#022c22","teal-50":"#f0fdfa","teal-100":"#ccfbf1","teal-200":"#99f6e4","teal-300":"#5eead4","teal-400":"#2dd4bf","teal-500":"#14b8a6","teal-600":"#0d9488","teal-700":"#0f766e","teal-800":"#115e59","teal-900":"#134e4a","teal-950":"#042f2e","cyan-50":"#ecfeff","cyan-100":"#cffafe","cyan-200":"#a5f3fc","cyan-300":"#67e8f9","cyan-400":"#22d3ee","cyan-500":"#06b6d4","cyan-600":"#0891b2","cyan-700":"#0e7490","cyan-800":"#155e75","cyan-900":"#164e63","cyan-950":"#083344","sky-50":"#f0f9ff","sky-100":"#e0f2fe","sky-200":"#bae6fd","sky-300":"#7dd3fc","sky-400":"#38bdf8","sky-500":"#0ea5e9","sky-600":"#0284c7","sky-700":"#0369a1","sky-800":"#075985","sky-900":"#0c4a6e","sky-950":"#082f49","blue-50":"#eff6ff","blue-100":"#dbeafe","blue-200":"#bfdbfe","blue-300":"#93c5fd","blue-400":"#60a5fa","blue-500":"#3b82f6","blue-600":"#2563eb","blue-700":"#1d4ed8","blue-800":"#1e40af","blue-900":"#1e3a8a","blue-950":"#172554","indigo-50":"#eef2ff","indigo-100":"#e0e7ff","indigo-200":"#c7d2fe","indigo-300":"#a5b4fc","indigo-400":"#818cf8","indigo-500":"#6366f1","indigo-600":"#4f46e5","indigo-700":"#4338ca","indigo-800":"#3730a3","indigo-900":"#312e81","indigo-950":"#1e1b4b","violet-50":"#f5f3ff","violet-100":"#ede9fe","violet-200":"#ddd6fe","violet-300":"#c4b5fd","violet-400":"#a78bfa","violet-500":"#8b5cf6","violet-600":"#7c3aed","violet-700":"#6d28d9","violet-800":"#5b21b6","violet-900":"#4c1d95","violet-950":"#2e1065","purple-50":"#faf5ff","purple-100":"#f3e8ff","purple-200":"#e9d5ff","purple-300":"#d8b4fe","purple-400":"#c084fc","purple-500":"#a855f7","purple-600":"#9333ea","purple-700":"#7e22ce","purple-800":"#6b21a8","purple-900":"#581c87","purple-950":"#3b0764","fuchsia-50":"#fdf4ff","fuchsia-100":"#fae8ff","fuchsia-200":"#f5d0fe","fuchsia-300":"#f0abfc","fuchsia-400":"#e879f9","fuchsia-500":"#d946ef","fuchsia-600":"#c026d3","fuchsia-700":"#a21caf","fuchsia-800":"#86198f","fuchsia-900":"#701a75","fuchsia-950":"#4a044e","pink-50":"#fdf2f8","pink-100":"#fce7f3","pink-200":"#fbcfe8","pink-300":"#f9a8d4","pink-400":"#f472b6","pink-500":"#ec4899","pink-600":"#db2777","pink-700":"#be185d","pink-800":"#9d174d","pink-900":"#831843","pink-950":"#500724","rose-50":"#fff1f2","rose-100":"#ffe4e6","rose-200":"#fecdd3","rose-300":"#fda4af","rose-400":"#fb7185","rose-500":"#f43f5e","rose-600":"#e11d48","rose-700":"#be123c","rose-800":"#9f1239","rose-900":"#881337","rose-950":"#4c0519",black:"#000000",white:"#ffffff"};function w(o,t,e){if(!o||o==="transparent"||o==="rgba(0, 0, 0, 0)")return{hex:"transparent",rgb:"transparent",hsl:"transparent",alpha:0,raw:o||"transparent"};if(o.startsWith("#")){let n=o,{r:l,g:a,b:r,a:s}=q(n),c=s===1?`rgb(${l}, ${a}, ${r})`:`rgba(${l}, ${a}, ${r}, ${s.toFixed(2)})`,p=z(l,a,r);return{hex:n,rgb:c,hsl:p,alpha:s,raw:o,tailwindClass:L(n)}}let i=o.match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)/);if(i){let n=Math.round(parseFloat(i[1])),l=Math.round(parseFloat(i[2])),a=Math.round(parseFloat(i[3])),r=i[4]!==void 0?parseFloat(i[4]):1,s=X(n,l,a,r),c=r===1?`rgb(${n}, ${l}, ${a})`:`rgba(${n}, ${l}, ${a}, ${r})`,p=z(n,l,a),d=L(s);return!d&&r===1&&(d=L(s.slice(0,7))),{hex:s,rgb:c,hsl:p,alpha:r,raw:o,tailwindClass:d}}return{hex:o,rgb:o,hsl:o,alpha:1,raw:o}}function q(o){let t=o.replace("#","");if(t.length===3&&(t=t.split("").map(e=>e+e).join("")),t.length===6){let e=parseInt(t,16);return{r:e>>16&255,g:e>>8&255,b:e&255,a:1}}if(t.length===8){let e=parseInt(t,16);return{r:e>>24&255,g:e>>16&255,b:e>>8&255,a:Math.round((e&255)/255*100)/100}}return{r:0,g:0,b:0,a:1}}function X(o,t,e,i=1){let n=a=>{let r=Math.max(0,Math.min(255,a)).toString(16);return r.length===1?"0"+r:r},l=`#${n(o)}${n(t)}${n(e)}`;if(i<1){let a=n(Math.round(i*255));return`${l}${a}`}return l}function z(o,t,e){o/=255,t/=255,e/=255;let i=Math.max(o,t,e),n=Math.min(o,t,e),l=0,a=0,r=(i+n)/2;if(i!==n){let s=i-n;switch(a=r>.5?s/(2-i-n):s/(i+n),i){case o:l=(t-e)/s+(t<e?6:0);break;case t:l=(e-o)/s+2;break;case e:l=(o-t)/s+4;break}l/=6}return`hsl(${Math.round(l*360)}, ${Math.round(a*100)}%, ${Math.round(r*100)}%)`}function L(o){let t=o.toLowerCase().slice(0,7);for(let[e,i]of Object.entries(O))if(i.toLowerCase()===t)return e}function D(o){let t=parseFloat(o);if(isNaN(t))return o;let e=t/16;return`${Number(e.toFixed(3))}rem`}function A(o){let t=parseFloat(o);if(isNaN(t)||t===0)return"rounded-none";if(t<=2)return"rounded-sm";if(t<=4)return"rounded";if(t<=6)return"rounded-md";if(t<=8)return"rounded-lg";if(t<=12)return"rounded-xl";if(t<=16)return"rounded-2xl";if(t<=24)return"rounded-3xl";if(t>=9999||t>100)return"rounded-full"}var k=[{label:"Text Color",cssProp:"color",category:"color",type:"color"},{label:"Background",cssProp:"background-color",category:"color",type:"color"},{label:"Border Color",cssProp:"border-color",category:"color",type:"color"},{label:"Font Size",cssProp:"font-size",category:"typography",type:"text",placeholder:"16px"},{label:"Font Weight",cssProp:"font-weight",category:"typography",type:"select",options:["100","200","300","400","500","600","700","800","900"]},{label:"Line Height",cssProp:"line-height",category:"typography",type:"text",placeholder:"1.5 or 24px"},{label:"Letter Spacing",cssProp:"letter-spacing",category:"typography",type:"text",placeholder:"0px"},{label:"Width",cssProp:"width",category:"dimensions",type:"text",placeholder:"auto or 200px"},{label:"Height",cssProp:"height",category:"dimensions",type:"text",placeholder:"auto or 44px"},{label:"Gap",cssProp:"gap",category:"dimensions",type:"text",placeholder:"8px or 1rem"},{label:"Display",cssProp:"display",category:"dimensions",type:"select",options:["block","flex","inline-flex","grid","inline-block","inline","none"]},{label:"Padding",cssProp:"padding",category:"spacing",type:"text",placeholder:"8px 16px"},{label:"Margin",cssProp:"margin",category:"spacing",type:"text",placeholder:"0px auto"},{label:"Border Radius",cssProp:"border-radius",category:"style",type:"text",placeholder:"8px or 9999px"},{label:"Border",cssProp:"border",category:"style",type:"text",placeholder:"1px solid #3b82f6"},{label:"Opacity",cssProp:"opacity",category:"style",type:"text",placeholder:"1 or 0.8"}],S=class{card;isPinned=!1;activeTab="inspect";currentData=null;currentTarget=null;onCopyCallback;onElementModified;userHasMovedCard=!1;currentCorner="bottom-right";originalStyles=new Map;originalInlineStyles=new Map;styleChanges=new Map;isDragging=!1;dragStartX=0;dragStartY=0;cardStartX=0;cardStartY=0;constructor(t,e,i){this.onCopyCallback=e,this.onElementModified=i,this.card=document.createElement("div"),this.card.className="ib-tooltip-card",this.card.style.display="none",t.appendChild(this.card),this.initCardDragging(),this.applyCornerPosition(this.currentCorner)}getPinned(){return this.isPinned}setPinned(t){this.isPinned=t,this.card.classList.toggle("ib-pinned",this.isPinned);let e=this.card.querySelector(".ib-pin-btn");e&&(e.classList.toggle("ib-active",this.isPinned),e.setAttribute("title",this.isPinned?"Locked (Click to unlock)":"Click or click element to lock"),e.textContent=this.isPinned?"\u{1F512}":"\u{1F513}")}update(t,e){this.isPinned||(this.currentTarget!==e&&(this.currentTarget=e,this.captureBaselineStyles(e),this.styleChanges.clear()),this.currentData=t,this.render(),this.userHasMovedCard||this.applyCornerPosition(this.currentCorner),this.card.style.display="flex")}hide(){this.isPinned||(this.card.style.display="none")}togglePin(){this.setPinned(!this.isPinned)}captureBaselineStyles(t){this.originalStyles.clear(),this.originalInlineStyles.clear();let e=window.getComputedStyle(t);k.forEach(i=>{this.originalInlineStyles.set(i.cssProp,t.style.getPropertyValue(i.cssProp));let n="";i.cssProp==="color"?n=w(e.color).hex:i.cssProp==="background-color"?n=w(e.backgroundColor).hex:i.cssProp==="border-color"?n=w(e.borderColor).hex:i.cssProp==="padding"?n=R(e.paddingTop,e.paddingRight,e.paddingBottom,e.paddingLeft):i.cssProp==="margin"?n=R(e.marginTop,e.marginRight,e.marginBottom,e.marginLeft):i.cssProp==="width"?n=t.style.width||`${Math.round(t.getBoundingClientRect().width)}px`:i.cssProp==="height"?n=t.style.height||`${Math.round(t.getBoundingClientRect().height)}px`:i.cssProp==="gap"?n=e.gap&&e.gap!=="normal"?e.gap:"0px":n=e.getPropertyValue(i.cssProp)||"",this.originalStyles.set(i.cssProp,n)})}applyCornerPosition(t){this.currentCorner=t;let e=24,i=390,n=Math.min(this.card.offsetHeight||460,560),l=window.innerWidth||1200,a=window.innerHeight||800,r=l-i-e,s=a-n-e;t==="bottom-left"?(r=e,s=a-n-e):t==="top-right"?(r=l-i-e,s=e):t==="top-left"&&(r=e,s=e),this.card.style.left=`${Math.round(r)}px`,this.card.style.top=`${Math.round(s)}px`,this.card.style.right="auto",this.card.style.bottom="auto"}initCardDragging(){let t=i=>{if(!this.isDragging)return;let n=i.clientX-this.dragStartX,l=i.clientY-this.dragStartY,a=this.cardStartX+n,r=this.cardStartY+l,s=12,c=(window.innerWidth||1200)-(this.card.offsetWidth||390)-s,p=(window.innerHeight||800)-(this.card.offsetHeight||460)-s;a=Math.max(s,Math.min(c,a)),r=Math.max(s,Math.min(p,r)),this.card.style.left=`${a}px`,this.card.style.top=`${r}px`,this.userHasMovedCard=!0},e=()=>{if(!this.isDragging)return;this.isDragging=!1,window.removeEventListener("pointermove",t,{capture:!0}),window.removeEventListener("pointerup",e,{capture:!0});let i=this.card.getBoundingClientRect(),n=window.innerWidth/2,l=window.innerHeight/2,a=i.left+i.width/2>=n,r=i.top+i.height/2>=l;r&&a?this.currentCorner="bottom-right":r&&!a?this.currentCorner="bottom-left":!r&&a?this.currentCorner="top-right":this.currentCorner="top-left"};this.card.addEventListener("pointerdown",i=>{let n=i.target;if(!n.closest(".ib-card-topbar")||n.closest("button")||n.closest(".ib-topbar-actions")||i.button!==0)return;this.isDragging=!0,this.dragStartX=i.clientX,this.dragStartY=i.clientY;let l=this.card.getBoundingClientRect();this.cardStartX=l.left,this.cardStartY=l.top,window.addEventListener("pointermove",t,{capture:!0}),window.addEventListener("pointerup",e,{capture:!0}),i.preventDefault()})}render(){if(!this.currentData)return;let t=this.currentData,e=`<span class="ib-badge ib-tag-badge">&lt;${t.tagName}&gt;</span>`,i=t.id?`<span class="ib-id-badge">#${h(t.id)}</span>`:"",n=t.classList.length?`<span class="ib-meta-dim">.${t.classList.slice(0,2).map(h).join(".")} ${t.classList.length>2?`+${t.classList.length-2}`:""}</span>`:"",l=this.styleChanges.size;this.card.innerHTML=`
      <div class="ib-card-topbar">
        <div class="ib-topbar-title">
          <div class="ib-logo-dot"></div>
          <span class="ib-brand">InspectBae</span>
          ${e}
          ${i}
          ${n}
        </div>
        <div class="ib-topbar-actions">
          <button class="ib-icon-btn ib-pin-btn ${this.isPinned?"ib-active":""}" title="${this.isPinned?"Locked (Click to unlock)":"Click to lock/freeze info"}">
            ${this.isPinned?"\u{1F512}":"\u{1F513}"}
          </button>
        </div>
      </div>

      <!-- Mode Tabs -->
      <div class="ib-mode-tabs">
        <button type="button" class="ib-tab-btn ${this.activeTab==="inspect"?"ib-tab-active":""}" data-mode="inspect">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          Inspect
        </button>
        <button type="button" class="ib-tab-btn ${this.activeTab==="custom"?"ib-tab-active":""}" data-mode="custom">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
          Custom Values
          ${l>0?`<span class="ib-tab-badge">${l}</span>`:""}
        </button>
      </div>

      <!-- Scrollable Content Body -->
      <div class="ib-card-content">
        ${this.activeTab==="inspect"?this.renderInspectTab():this.renderCustomTab()}
      </div>

      <!-- Persistent Copy Toolbar Footer -->
      <div class="ib-copy-toolbar">
        <button type="button" class="ib-action-btn ib-copy-note-btn" title="Copy handover notes in Markdown format">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
          Copy Note
        </button>
        <button type="button" class="ib-action-btn ib-copy-css" title="Copy clean CSS snippet">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/></svg>
          CSS
        </button>
        ${t.frameworks.tailwind.matchedClasses.length>0?`
          <button type="button" class="ib-action-btn ib-copy-tw-all" title="Copy Tailwind utility classes">
            Tailwind
          </button>
        `:""}
        <button type="button" class="ib-action-btn ib-copy-color-btn" title="Copy element colors">
          Color
        </button>
        ${t.frameworks.react?`
          <button type="button" class="ib-action-btn ib-copy-comp-btn" title="Copy React component name">
            Component
          </button>
        `:""}
      </div>
    `,this.bindEvents(),this.activeTab==="custom"&&this.bindCustomTabEvents()}renderInspectTab(){if(!this.currentData)return"";let t=this.currentData,e=t.frameworks.react?`<div class="ib-fw-pill ib-react-pill" title="React Component">
           <svg width="12" height="12" viewBox="-11.5 -10.23174 23 20.46348"><circle cx="0" cy="0" r="2.05" fill="#00d8ff"/><g stroke="#00d8ff" stroke-width="1" fill="none"><ellipse rx="11" ry="4.2"/><ellipse rx="11" ry="4.2" transform="rotate(60)"/><ellipse rx="11" ry="4.2" transform="rotate(120)"/></g></svg>
           <span>${h(t.frameworks.react.componentName)}</span>
         </div>`:"",i=t.frameworks.radix?`<div class="ib-fw-pill ib-radix-pill" title="Radix UI Primitive">
           <span class="ib-pill-dot" style="background:#8e4ec6;"></span>
           <span>Radix: ${h(t.frameworks.radix.primitive)}</span>
           ${t.frameworks.radix.state?`<span class="ib-pill-state">[${h(t.frameworks.radix.state)}]</span>`:""}
         </div>`:"",n=t.frameworks.tailwind.matchedClasses.length>0?`<div class="ib-fw-pill ib-tw-pill" title="Tailwind CSS">
           <svg width="12" height="12" viewBox="0 0 24 24" fill="#38bdf8"><path d="M12.001,4.8c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c0.913,0.228,1.565,0.89,2.288,1.624 C13.666,10.618,15.027,12,18.001,12c3.2,0,5.2-1.6,6-4.8c-1.2,1.6-2.6,2.2-4.2,1.8c-0.913-0.228-1.565-0.89-2.288-1.624 C16.337,6.182,14.976,4.8,12.001,4.8z M6.001,12c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c0.913,0.228,1.565,0.89,2.288,1.624 c1.177,1.194,2.538,2.576,5.512,2.576c3.2,0,5.2-1.6,6-4.8c-1.2,1.6-2.6,2.2-4.2,1.8c-0.913-0.228-1.565-0.89-2.288-1.624 C10.337,13.382,8.976,12,6.001,12z"/></svg>
           <span>${t.frameworks.tailwind.matchedClasses.length} Tailwind utilities</span>
         </div>`:"",l=H("BG",t.styling.backgroundColor),a=H("Text",t.typography.color),r=t.boxModel.margin,s=t.boxModel.padding,c="";t.frameworks.cssVariables.length>0&&(c=`
        <div class="ib-section">
          <div class="ib-section-header">
            <span>CSS Variables & Tokens</span>
            <span class="ib-count">${t.frameworks.cssVariables.length}</span>
          </div>
          <div class="ib-vars-grid">
            ${t.frameworks.cssVariables.map(d=>`
              <div class="ib-var-item" data-copy="var(${h(d.variableName)})">
                <span class="ib-var-name" title="${h(d.variableName)}">${h(d.variableName)}</span>
                <span class="ib-var-val" title="${h(d.computedValue)}">${h(d.computedValue)}</span>
              </div>
            `).join("")}
          </div>
        </div>
      `);let p="";if(t.frameworks.tailwind.matchedClasses.length>0){let d=t.frameworks.tailwind.matchedClasses.slice(0,14),f=t.frameworks.tailwind.matchedClasses.length-d.length;p=`
        <div class="ib-section">
          <div class="ib-section-header">
            <span>Tailwind Classes</span>
            <button class="ib-btn-subtle ib-copy-tw-btn">Copy All</button>
          </div>
          <div class="ib-pills-wrap">
            ${d.map(m=>`<span class="ib-tw-badge" data-copy="${h(m)}">${h(m)}</span>`).join("")}
            ${f>0?`<span class="ib-more-badge">+${f} more</span>`:""}
          </div>
        </div>
      `}return`
      <!-- Framework Badges -->
      ${e||i||n?`
        <div class="ib-fw-bar">
          ${e}
          ${i}
          ${n}
        </div>
      `:""}

      <!-- Dimensions Strip -->
      <div class="ib-dim-strip">
        <div class="ib-dim-item">
          <span class="ib-dim-label">Dimensions</span>
          <span class="ib-dim-val">${t.rect.width} \xD7 ${t.rect.height} px</span>
        </div>
        <div class="ib-dim-item">
          <span class="ib-dim-label">Display</span>
          <span class="ib-dim-val">${t.styling.display}</span>
        </div>
        <div class="ib-dim-item">
          <span class="ib-dim-label">Position</span>
          <span class="ib-dim-val">${t.styling.position}</span>
        </div>
      </div>

      <!-- Typography -->
      <div class="ib-section">
        <div class="ib-section-header">
          <span>Typography</span>
          <button class="ib-btn-subtle ib-copy-font-btn">Copy Font</button>
        </div>
        <div class="ib-grid-2col">
          <div class="ib-prop-row">
            <span class="ib-prop-key">Family</span>
            <span class="ib-prop-val ib-font-name" title="${h(t.typography.fontFamily)}">
              ${h(t.typography.detectedFontName)}
              ${t.typography.isWebFont?'<span class="ib-webfont-tag">webfont</span>':""}
            </span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Size / Weight</span>
            <span class="ib-prop-val">${t.typography.fontSize} / ${t.typography.fontWeight}</span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Line Height</span>
            <span class="ib-prop-val">${t.typography.lineHeight}</span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Color</span>
            <span class="ib-prop-val">${a}</span>
          </div>
        </div>
      </div>

      <!-- Box Model Visualizer -->
      <div class="ib-section">
        <div class="ib-section-header">
          <span>Box Model (m / p)</span>
        </div>
        <div class="ib-mini-boxmodel">
          <div class="ib-bm-margin" title="Margin: ${r.top} ${r.right} ${r.bottom} ${r.left}">
            <span class="ib-bm-label">M: ${r.top} ${r.right} ${r.bottom} ${r.left}</span>
            <div class="ib-bm-padding" title="Padding: ${s.top} ${s.right} ${s.bottom} ${s.left}">
              <span class="ib-bm-label">P: ${s.top} ${s.right} ${s.bottom} ${s.left}</span>
              <div class="ib-bm-content">${t.rect.width} \xD7 ${t.rect.height}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Styling & Effects -->
      <div class="ib-section">
        <div class="ib-section-header">
          <span>Styling & Effects</span>
        </div>
        <div class="ib-grid-2col">
          <div class="ib-prop-row">
            <span class="ib-prop-key">Background</span>
            <span class="ib-prop-val">${l}</span>
          </div>
          <div class="ib-prop-row">
            <span class="ib-prop-key">Border Radius</span>
            <span class="ib-prop-val">${t.styling.borderRadius.value} ${t.styling.borderRadius.tailwindMatch?`<span class="ib-tw-mini-tag">${t.styling.borderRadius.tailwindMatch}</span>`:""}</span>
          </div>
          ${t.styling.border!=="none"?`
            <div class="ib-prop-row ib-col-span-2">
              <span class="ib-prop-key">Border</span>
              <span class="ib-prop-val ib-truncate" title="${h(t.styling.border)}">${h(t.styling.border)}</span>
            </div>
          `:""}
          ${t.styling.boxShadow!=="none"?`
            <div class="ib-prop-row ib-col-span-2">
              <span class="ib-prop-key">Shadow</span>
              <span class="ib-prop-val ib-truncate" title="${h(t.styling.boxShadow)}">${h(t.styling.boxShadow)}</span>
            </div>
          `:""}
        </div>
      </div>

      <!-- Tailwind Section -->
      ${p}

      <!-- CSS Variables Section -->
      ${c}
    `}renderCustomTab(){let t=this.styleChanges.size,e=s=>{let c=this.styleChanges.has(s.cssProp),p=c?this.styleChanges.get(s.cssProp).current:this.originalStyles.get(s.cssProp)||"",d="";if(s.type==="color"){let f=I(p);d=`
          <div class="ib-color-picker-row">
            <input type="color" class="ib-color-input-native" data-color-sync="${s.cssProp}" value="${f}" />
            <input type="text" class="ib-input ${c?"ib-input-changed":""}" data-prop="${s.cssProp}" value="${h(p)}" placeholder="#rrggbb or rgb()" />
          </div>
        `}else s.type==="select"?d=`
          <select class="ib-select ${c?"ib-input-changed":""}" data-prop="${s.cssProp}">
            ${s.options?.map(f=>`<option value="${f}" ${f===p?"selected":""}>${f}</option>`).join("")}
          </select>
        `:d=`
          <input type="text" class="ib-input ${c?"ib-input-changed":""}" data-prop="${s.cssProp}" value="${h(p)}" placeholder="${s.placeholder||""}" />
        `;return`
        <div class="ib-field-group">
          <label class="ib-field-label">
            <span>${s.label}</span>
            ${c?'<span class="ib-changed-dot" title="Modified value"></span>':""}
          </label>
          ${d}
        </div>
      `},i=k.filter(s=>s.category==="color").map(e).join(""),n=k.filter(s=>s.category==="typography").map(e).join(""),l=k.filter(s=>s.category==="dimensions").map(e).join(""),a=k.filter(s=>s.category==="spacing").map(e).join(""),r=k.filter(s=>s.category==="style").map(e).join("");return`
      <div class="ib-custom-container">
        <!-- Status Bar -->
        <div class="ib-custom-status-bar">
          <div class="ib-custom-status-text">
            <span class="ib-live-indicator"></span>
            <span>Live Edit Active ${t>0?`(${t} tweaked)`:""}</span>
          </div>
          ${t>0?`
            <button type="button" class="ib-btn-reset-all" title="Revert all tweaked styles to baseline">
              \u21BA Reset All
            </button>
          `:""}
        </div>

        <!-- Colors -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Colors</span>
          <div class="ib-custom-grid">
            ${i}
          </div>
        </div>

        <!-- Typography -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Typography</span>
          <div class="ib-custom-grid">
            ${n}
          </div>
        </div>

        <!-- Layout & Size -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Dimensions & Layout</span>
          <div class="ib-custom-grid">
            ${l}
          </div>
        </div>

        <!-- Spacing -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Spacing (Padding & Margin)</span>
          <div class="ib-custom-grid">
            ${a}
          </div>
        </div>

        <!-- Borders & Effects -->
        <div class="ib-custom-section">
          <span class="ib-custom-sec-title">Borders & Effects</span>
          <div class="ib-custom-grid">
            ${r}
          </div>
        </div>
      </div>
    `}bindEvents(){if(!this.currentData)return;let t=this.currentData;this.card.querySelector(".ib-pin-btn")?.addEventListener("click",d=>{d.stopPropagation(),this.togglePin()}),this.card.querySelectorAll(".ib-tab-btn").forEach(d=>{d.addEventListener("click",f=>{f.stopPropagation();let m=d.getAttribute("data-mode");m&&m!==this.activeTab&&(this.activeTab=m,m==="custom"&&this.setPinned(!0),this.render())})}),this.card.querySelector(".ib-copy-font-btn")?.addEventListener("click",d=>{d.stopPropagation();let f=`font-family: ${t.typography.fontFamily};
font-size: ${t.typography.fontSize};
font-weight: ${t.typography.fontWeight};`;this.copy(f,"Font properties copied")}),this.card.querySelectorAll(".ib-copy-tw-btn, .ib-copy-tw-all").forEach(d=>{d.addEventListener("click",f=>{f.stopPropagation(),this.copy(t.frameworks.tailwind.matchedClasses.join(" "),"Tailwind classes copied")})}),this.card.querySelectorAll("[data-copy]").forEach(d=>{d.addEventListener("click",f=>{f.stopPropagation();let m=d.getAttribute("data-copy");m&&this.copy(m,`Copied "${m}"`)})}),this.card.querySelector(".ib-copy-note-btn")?.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation();let f=this.generateMarkdownNote();this.copy(f,"Handover Note (Markdown) copied!")}),this.card.querySelector(".ib-copy-css")?.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation();let f=[`/* <${t.tagName}> styles */`,`width: ${t.rect.width}px;`,`height: ${t.rect.height}px;`,`font-family: ${t.typography.fontFamily};`,`font-size: ${t.typography.fontSize};`,`font-weight: ${t.typography.fontWeight};`,`color: ${t.typography.color.hex};`,t.styling.backgroundColor.hex!=="transparent"?`background-color: ${t.styling.backgroundColor.hex};`:"",t.styling.borderRadius.value!=="0px"?`border-radius: ${t.styling.borderRadius.value};`:"",t.styling.border!=="none"?`border: ${t.styling.border};`:"",t.styling.boxShadow!=="none"?`box-shadow: ${t.styling.boxShadow};`:"",`padding: ${t.boxModel.padding.top}px ${t.boxModel.padding.right}px ${t.boxModel.padding.bottom}px ${t.boxModel.padding.left}px;`,`margin: ${t.boxModel.margin.top}px ${t.boxModel.margin.right}px ${t.boxModel.margin.bottom}px ${t.boxModel.margin.left}px;`].filter(Boolean).join(`
`);this.copy(f,"CSS snippet copied")}),this.card.querySelector(".ib-copy-color-btn")?.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation();let f=t.styling.backgroundColor.hex!=="transparent"?t.styling.backgroundColor.hex:t.typography.color.hex;this.copy(f,`Color ${f} copied`)}),this.card.querySelector(".ib-copy-comp-btn")?.addEventListener("click",d=>{d.preventDefault(),d.stopPropagation(),t.frameworks.react&&this.copy(t.frameworks.react.componentName,`Component <${t.frameworks.react.componentName}> copied`)})}bindCustomTabEvents(){this.card.querySelector(".ib-btn-reset-all")?.addEventListener("click",n=>{n.stopPropagation(),this.resetAllChanges()}),this.card.querySelectorAll("[data-prop]").forEach(n=>{let l=n.getAttribute("data-prop");if(!l)return;let a=()=>{this.applyLiveStyle(l,n.value);let r=this.card.querySelector(`[data-color-sync="${l}"]`);if(r){let s=I(n.value);(s!=="#000000"||n.value.toLowerCase()==="#000000"||n.value.toLowerCase()==="black")&&(r.value=s)}};n.addEventListener("input",a),n.addEventListener("change",a)}),this.card.querySelectorAll("[data-color-sync]").forEach(n=>{let l=n.getAttribute("data-color-sync");if(!l)return;let a=()=>{let r=this.card.querySelector(`input[data-prop="${l}"]`);r&&(r.value=n.value),this.applyLiveStyle(l,n.value)};n.addEventListener("input",a),n.addEventListener("change",a)})}applyLiveStyle(t,e){if(!this.currentTarget)return;let i=e.trim(),n=this.originalStyles.get(t)??"";if(i===""||i===n){let l=this.originalInlineStyles.get(t);l?this.currentTarget.style.setProperty(t,l):this.currentTarget.style.removeProperty(t),this.styleChanges.delete(t)}else{this.currentTarget.style.setProperty(t,i,"important");let l=k.find(a=>a.cssProp===t);this.styleChanges.set(t,{label:l?l.label:t,cssProp:t,original:n||"initial",current:i})}if(this.updateVisualChangeIndicators(t),this.onElementModified)try{this.onElementModified(this.currentTarget)}catch(l){console.error("[InspectBae] Error updating modified element:",l)}}updateVisualChangeIndicators(t){let e=this.styleChanges.has(t),i=this.card.querySelector(`[data-prop="${t}"]`);if(i){i.classList.toggle("ib-input-changed",e);let r=i.closest(".ib-field-group");if(r){let s=r.querySelector(".ib-field-label");if(s){let c=s.querySelector(".ib-changed-dot");if(e&&!c){let p=document.createElement("span");p.className="ib-changed-dot",p.title="Modified value",s.appendChild(p)}else!e&&c&&c.remove()}}}let n=this.card.querySelector('[data-mode="custom"]');if(n){let r=this.styleChanges.size,s=n.querySelector(".ib-tab-badge");r>0?(s||(s=document.createElement("span"),s.className="ib-tab-badge",n.appendChild(s)),s.textContent=`${r}`):s&&s.remove()}let l=this.card.querySelector(".ib-custom-status-text span:nth-child(2)");if(l){let r=this.styleChanges.size;l.textContent=`Live Edit Active ${r>0?`(${r} tweaked)`:""}`}let a=this.card.querySelector(".ib-custom-status-bar");if(a){let r=a.querySelector(".ib-btn-reset-all");this.styleChanges.size>0&&!r?(r=document.createElement("button"),r.setAttribute("type","button"),r.className="ib-btn-reset-all",r.setAttribute("title","Revert all tweaked styles to baseline"),r.textContent="\u21BA Reset All",r.addEventListener("click",s=>{s.stopPropagation(),this.resetAllChanges()}),a.appendChild(r)):this.styleChanges.size===0&&r&&r.remove()}}resetAllChanges(){this.currentTarget&&(this.styleChanges.forEach((t,e)=>{let i=this.originalInlineStyles.get(e);i?this.currentTarget.style.setProperty(e,i):this.currentTarget.style.removeProperty(e)}),this.styleChanges.clear(),this.render(),this.onElementModified&&this.onElementModified(this.currentTarget),this.onCopyCallback&&this.onCopyCallback("","All styles reverted to original"))}generateMarkdownNote(){if(!this.currentData||!this.currentTarget)return"";let t=this.currentData,e=Array.from(this.styleChanges.values()),i=[`<${t.tagName}>`,t.id?`#${t.id}`:"",t.classList.length?`.${t.classList.slice(0,3).map(h).join(".")}`:""].filter(Boolean).join(" "),l=new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),a=`### \u{1F4DD} Design Tweak Handover Notes

`;return a+=`**Target Element:** \`${i}\`
`,t.frameworks.react?.componentName&&(a+=`**React Component:** \`<${t.frameworks.react.componentName}>\`
`,t.frameworks.react.hierarchy&&t.frameworks.react.hierarchy.length>1&&(a+=`**Component Tree:** ${t.frameworks.react.hierarchy.map(r=>`\`<${r}>\``).join(" \u2794 ")}
`)),t.frameworks.radix?.primitive&&(a+=`**Radix UI Primitive:** \`${t.frameworks.radix.primitive}\`${t.frameworks.radix.state?` (state: \`${t.frameworks.radix.state}\`)`:""}
`),a+=`
---

`,e.length>0?(a+=`#### \u{1F504} Modified Properties (${e.length})

`,e.forEach(r=>{a+=`- **${r.label}** (\`${r.cssProp}\`): \`${r.original}\` \u2794 **\`${r.current}\`**
`}),a+=`
#### \u{1F4CB} CSS Snippet to Apply:
\`\`\`css
/* Applied to ${i} */
`,e.forEach(r=>{a+=`${r.cssProp}: ${r.current};
`}),a+="```\n"):(a+=`#### \u{1F4D0} Current Computed Specs (No custom changes made)

`,a+=`- **Dimensions:** \`${t.rect.width} \xD7 ${t.rect.height}px\`
`,a+=`- **Display / Position:** \`${t.styling.display}\` / \`${t.styling.position}\`
`,a+=`- **Font:** \`${t.typography.fontFamily}\` | \`${t.typography.fontSize}\` / \`${t.typography.fontWeight}\` | \`${t.typography.lineHeight}\`
`,a+=`- **Color:** \`${t.typography.color.hex}\`
`,a+=`- **Background:** \`${t.styling.backgroundColor.hex}\`
`,a+=`- **Padding:** \`${t.boxModel.padding.top}px ${t.boxModel.padding.right}px ${t.boxModel.padding.bottom}px ${t.boxModel.padding.left}px\`
`,a+=`- **Margin:** \`${t.boxModel.margin.top}px ${t.boxModel.margin.right}px ${t.boxModel.margin.bottom}px ${t.boxModel.margin.left}px\`
`,t.styling.borderRadius.value!=="0px"&&(a+=`- **Border Radius:** \`${t.styling.borderRadius.value}\`
`),t.styling.border!=="none"&&(a+=`- **Border:** \`${t.styling.border}\`
`)),a+=`
---
*Exported via InspectBae DevTools (${l})*
`,a}copy(t,e){if(this.onCopyCallback)try{this.onCopyCallback(t,e)}catch(i){console.error("Error invoking onCopyCallback:",i)}else navigator.clipboard&&navigator.clipboard.writeText&&navigator.clipboard.writeText(t)}destroy(){this.card.remove()}};function H(o,t){return t.hex==="transparent"?'<span class="ib-color-wrap"><span class="ib-swatch ib-swatch-trans"></span><span class="ib-color-val">transparent</span></span>':`
    <span class="ib-color-wrap" data-copy="${h(t.hex)}" title="Click to copy ${h(t.hex)}">
      <span class="ib-swatch" style="background:${h(t.hex)};"></span>
      <span class="ib-color-hex">${h(t.hex)}</span>
      ${t.tailwindClass?`<span class="ib-tw-mini-tag">${h(t.tailwindClass)}</span>`:""}
    </span>
  `}function I(o){if(!o||o==="transparent")return"#000000";let t=w(o);return t.hex&&t.hex.startsWith("#")&&t.hex.length>=7?t.hex.slice(0,7):"#000000"}function R(o,t,e,i){return o===t&&t===e&&e===i?o:o===e&&t===i?`${o} ${t}`:`${o} ${t} ${e} ${i}`}function h(o){return o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}function N(o){try{let t=o,e=null;for(let a=0;a<5&&t;a++){let s=Object.keys(t).find(c=>c.startsWith("__reactFiber$")||c.startsWith("__reactInternalInstance$"));if(s){e=t[s];break}t=t.parentElement}if(!e){let a=Object.keys(o).filter(r=>r.startsWith("__reactProps$"));if(a.length>0){let r=o[a[0]];if(r&&typeof r=="object")return{componentName:"ReactElement",propsCount:Object.keys(r).length}}return}let i=[],n=e,l="";for(;n;){let a=F(n);a&&!U(a)&&(l||(l=a),i.push(a)),n=n.return}if(l){let a=e.memoizedProps||e.pendingProps,r=a?Object.keys(a).length:void 0;return{componentName:l,hierarchy:i.slice(0,5),propsCount:r}}}catch{}}function F(o){if(!o||!o.type||typeof o.type=="string")return null;if(typeof o.type=="function")return o.type.displayName||o.type.name||"AnonymousComponent";if(typeof o.type=="object"){if(o.type.displayName)return o.type.displayName;if(o.type.render)return o.type.render.displayName||o.type.render.name||"ForwardRef";if(o.type.type)return F({type:o.type.type})}return null}function U(o){return["Fragment","Suspense","StrictMode","Provider","Consumer","Context"].includes(o)}function V(o){try{let t=o,e={},i="",n="",l="";for(let a=0;a<5&&t;a++){let r=Array.from(t.attributes),s=!1;for(let c of r){let p=c.name,d=c.value;if((p.startsWith("data-radix-")||p==="data-state"||p==="data-orientation"||p==="data-side"||p==="data-align"||p==="data-placeholder")&&(e[p]=d,s=!0),p.startsWith("data-radix-")){let f=p.replace("data-radix-","").split("-");f.length>0&&!i&&(i=f.map(m=>m.charAt(0).toUpperCase()+m.slice(1)).join(""))}p==="data-state"&&(l=d)}if(!i&&s&&(i=G(t)),i)break;t=t.parentElement}if(Object.keys(e).length>0||i)return{primitive:i||"RadixPrimitive",part:n||void 0,state:l||void 0,attributes:e}}catch{}}function G(o){let t=o.getAttribute("role"),e=o.tagName.toLowerCase(),i=o.id||"",n=o.className||"";return o.hasAttribute("data-radix-collection-item")?"CollectionItem":t==="dialog"||o.hasAttribute("data-radix-dialog-content")?"Dialog":t==="menu"||t==="menuitem"||o.hasAttribute("data-radix-dropdown-menu-trigger")?"DropdownMenu":t==="tooltip"||o.hasAttribute("data-radix-tooltip-trigger")?"Tooltip":t==="tab"||t==="tablist"||t==="tabpanel"?"Tabs":t==="switch"?"Switch":t==="checkbox"?"Checkbox":t==="combobox"?"Select / Combobox":o.hasAttribute("data-radix-accordion-item")||o.hasAttribute("data-radix-accordion-trigger")?"Accordion":o.hasAttribute("data-radix-popover-content")||o.hasAttribute("data-radix-popover-trigger")?"Popover":o.hasAttribute("data-radix-scroll-area-viewport")?"ScrollArea":o.hasAttribute("data-state")?"RadixPrimitive":""}function W(o){let t=Array.from(o.classList),e=[],i={typography:[],layout:[],spacing:[],colors:[],effects:[],borders:[],other:[]};for(let n of t)if(K(n)){e.push(n);let l=Z(n);i[l].push(n)}return{matchedClasses:e,categorized:i}}function K(o){return[/^(p|px|py|pt|pr|pb|pl|m|mx|my|mt|mr|mb|ml|space-[xy]|gap|gap-[xy])-(\d+|\[.+\]|auto|px)$/,/^(flex|inline-flex|grid|inline-grid|block|inline-block|inline|hidden)$/,/^(flex-(row|row-reverse|col|col-reverse|wrap|wrap-reverse|nowrap|1|auto|initial|none))$/,/^(items|justify|content|self|place)-(start|end|center|between|around|evenly|stretch|baseline|auto)/,/^(grid-cols|grid-rows|col-span|row-span)-/,/^(w|min-w|max-w|h|min-h|max-h)-(\d+|\[.+\]|auto|full|screen|fit|min|max|px)/,/^(text|font|leading|tracking)-(xs|sm|base|lg|xl|\dxl|thin|extralight|light|normal|medium|semibold|bold|extrabold|black|tight|snug|normal|relaxed|loose|tighter|wider|widest|center|left|right|justify)/,/^(underline|line-through|no-underline|uppercase|lowercase|capitalize|italic|not-italic|truncate)/,/^(bg|text|border|ring|accent|fill|stroke)-([a-z]+-\d+|white|black|transparent|current|\[.+\])/,/^(rounded|rounded-(t|r|b|l|tl|tr|br|bl))(-[a-z0-9]+|\[.+\])?$/,/^(border|border-[trblxy])(-(\d+|\[.+\]))?$/,/^(ring|ring-offset)(-(\d+|\[.+\]))?$/,/^(shadow|shadow-(sm|md|lg|xl|2xl|inner|none)|opacity-\d+|blur|backdrop-blur|blur-[a-z0-9]+)/,/^(relative|absolute|fixed|sticky|static)$/,/^(top|right|bottom|left|inset|inset-[xy])-(\d+|auto|full|px|\[.+\])/,/^(z)-(\d+|auto|\[.+\])/,/^(transition|duration-\d+|ease-[a-z]+|scale-\d+|rotate-\d+|translate-[xy]-\d+)/,/^(overflow|overflow-[xy])-(auto|hidden|clip|visible|scroll)/,/^(cursor)-(pointer|default|not-allowed|text|move)/].some(e=>e.test(o))}function Z(o){return/^(text|font|leading|tracking|underline|italic|truncate|uppercase|lowercase)/.test(o)?"typography":/^(p|px|py|pt|pr|pb|pl|m|mx|my|mt|mr|mb|ml|space|gap)/.test(o)?"spacing":/^(bg|text|border)-([a-z]+-\d+|white|black|transparent)/.test(o)?"colors":/^(rounded|border|ring)/.test(o)?"borders":/^(shadow|opacity|blur|backdrop)/.test(o)?"effects":/^(flex|grid|block|inline|items|justify|w-|h-|min-|max-|relative|absolute|fixed|sticky|overflow)/.test(o)?"layout":"other"}function j(o,t){let e=[],i=["background-color","color","border-color","border-radius","font-family","font-size","gap","padding","margin","box-shadow","fill","stroke"];for(let n=0;n<o.style.length;n++){let l=o.style[n],r=o.style.getPropertyValue(l).match(/var\((--[a-zA-Z0-9-_]+)\)/g);if(r)for(let s of r){let c=s.replace(/var\(|\)/g,"").trim(),p=t.getPropertyValue(c).trim();e.push({property:l,variableName:c,computedValue:p||t.getPropertyValue(l)})}}try{let n=getComputedStyle(document.documentElement),l=["--tw-","--ds-","--color-","--primary","--secondary","--background","--foreground","--radius","--font-","--space-","--shadow-"],a=new Map;for(let r of Array.from(document.styleSheets))try{let s=r.cssRules||r.rules;if(!s)continue;for(let c of Array.from(s))if(c instanceof CSSStyleRule){let p=!1;try{(c.selectorText===":root"||c.selectorText==="html"||c.selectorText==="body"||o.matches(c.selectorText))&&(p=!0)}catch{}if(p){let d=c.style;for(let f=0;f<d.length;f++){let m=d[f];if(m.startsWith("--")){let y=d.getPropertyValue(m).trim();a.set(m,y)}}}}}catch{}for(let r of i){let s=t.getPropertyValue(r).trim();if(s)for(let[c,p]of a.entries()){let d=t.getPropertyValue(c).trim()||n.getPropertyValue(c).trim();d&&(d===s||s.includes(d)&&d.length>3)&&(e.some(f=>f.variableName===c&&f.property===r)||e.push({property:r,variableName:c,computedValue:s}))}}}catch{}return e.slice(0,10)}function P(o){let t=window.getComputedStyle(o),e=o.getBoundingClientRect(),i=x=>{let v=parseFloat(x);return isNaN(v)?0:Math.round(v)},n={margin:{top:i(t.marginTop),right:i(t.marginRight),bottom:i(t.marginBottom),left:i(t.marginLeft)},padding:{top:i(t.paddingTop),right:i(t.paddingRight),bottom:i(t.paddingBottom),left:i(t.paddingLeft)},border:{top:i(t.borderTopWidth),right:i(t.borderRightWidth),bottom:i(t.borderBottomWidth),left:i(t.borderLeftWidth)}},l=t.fontFamily||"",a=l.split(",")[0].replace(/['"]/g,"").trim(),r=J(a),s=w(t.color,o,"color"),c=w(t.backgroundColor,o,"background-color"),p=t.borderRadius,d=D(p),f=A(p),m=t.borderWidth,y=t.borderStyle,$=t.borderColor,C=m!=="0px"&&y!=="none"?`${m} ${y} ${$}`:"none",E=N(o),b=V(o),g=W(o),u=j(o,t);return{tagName:o.tagName.toLowerCase(),id:o.id||void 0,classList:Array.from(o.classList),rect:{x:Math.round(e.x),y:Math.round(e.y),width:Math.round(e.width),height:Math.round(e.height),top:Math.round(e.top),left:Math.round(e.left),bottom:Math.round(e.bottom),right:Math.round(e.right)},boxModel:n,typography:{fontFamily:l,detectedFontName:a,isWebFont:r,fontSize:t.fontSize,fontWeight:t.fontWeight,lineHeight:t.lineHeight,letterSpacing:t.letterSpacing,color:s},styling:{backgroundColor:c,border:C,borderRadius:{value:p,rem:d,tailwindMatch:f},boxShadow:t.boxShadow!=="none"?t.boxShadow:"none",opacity:t.opacity,backdropFilter:t.backdropFilter||t.webkitBackdropFilter||"none",display:t.display,position:t.position,zIndex:t.zIndex},frameworks:{react:E,radix:b,tailwind:g,cssVariables:u}}}function J(o){return!o||["system-ui","-apple-system","BlinkMacSystemFont","Segoe UI","Roboto","Helvetica Neue","Arial","sans-serif","serif","monospace","Times New Roman","Georgia","Courier New","Verdana","Tahoma","Trebuchet MS"].map(e=>e.toLowerCase()).includes(o.toLowerCase())?!1:document.fonts&&document.fonts.check?document.fonts.check(`12px "${o}"`):!0}(function(){if(window.__INSPECT_BAE_LOADED__)return;window.__INSPECT_BAE_LOADED__=!0;let o=!1,t=null,e=null,i=null,n=null,l=null,a=null;function r(){if(e)return;e=document.createElement("div"),e.id="inspect-bae-root",e.style.position="fixed",e.style.top="0",e.style.left="0",e.style.width="0",e.style.height="0",e.style.zIndex="2147483647",e.style.pointerEvents="none",i=e.attachShadow({mode:"open"});let b=document.createElement("style");b.textContent=B,i.appendChild(b),l=new T(i),a=new S(i,m,f),n=new M(i,s),document.documentElement.appendChild(e)}function s(b){o=b!==void 0?b:!o,n&&n.setActive(o),o?(C(),y("InspectBae: Inspection Mode Active")):(E(),l&&l.hide(),a&&a.hide(),y("InspectBae: Inspection Mode Deactivated"));try{typeof chrome<"u"&&chrome.runtime&&chrome.runtime.sendMessage&&chrome.runtime.sendMessage({type:"STATE_UPDATE",payload:{isEnabled:o}})}catch{}}function c(b){if(!o||a&&a.getPinned())return;if(e){let u=b.composedPath?b.composedPath():[];if(u.includes(e)||i&&u.some(x=>x instanceof Node&&i.contains(x)))return}let g=b.target;if((!g||g===e||g.id==="inspect-bae-root")&&(g=document.elementFromPoint(b.clientX,b.clientY)),!(!g||g===t||g===e||g.id==="inspect-bae-root")){t=g;try{let u=P(g);l&&l.update(g,u),a&&a.update(u,g)}catch(u){console.error("[InspectBae] Error extracting element data:",u)}}}function p(b){if(o){if(e){let g=b.composedPath?b.composedPath():[];if(g.includes(e)||i&&g.some(u=>u instanceof Node&&i.contains(u)))return}if(a){let g=!a.getPinned();a.setPinned(g),y(g?"Element Locked! You can now scroll info or drag card.":"Element Unlocked. Hover to inspect another."),b.preventDefault(),b.stopPropagation()}}}function d(b){let g=document.activeElement;(b.composedPath?b.composedPath():[]).some(v=>v instanceof HTMLElement&&(v.tagName==="INPUT"||v.tagName==="TEXTAREA"||v.tagName==="SELECT"))||g&&(g.tagName==="INPUT"||g.tagName==="TEXTAREA"||g.tagName==="SELECT")||(b.key==="Escape"&&o&&(a&&a.getPinned()?(a.setPinned(!1),y("Element Unlocked")):s(!1)),(b.key==="p"||b.key==="P")&&o&&a&&a.togglePin())}function f(b){if(!(!b||!l))try{let g=P(b);l.update(b,g)}catch(g){console.error("[InspectBae] Error updating overlay on modification:",g)}}function m(b,g){try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(b).catch(()=>{});else{let u=document.createElement("textarea");u.value=b,u.style.position="fixed",u.style.opacity="0",document.body.appendChild(u),u.select(),document.execCommand("copy"),u.remove()}}catch{}y(g)}function y(b){if(!i)return;i.querySelectorAll(".ib-toast").forEach(x=>x.remove());let u=document.createElement("div");u.className="ib-toast",u.innerHTML=`
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
      <span>${$(b)}</span>
    `,i.appendChild(u),setTimeout(()=>{u.remove()},2100)}function $(b){return b.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function C(){window.addEventListener("pointermove",c,{passive:!0,capture:!0}),window.addEventListener("mousemove",c,{passive:!0,capture:!0}),window.addEventListener("click",p,{capture:!0}),window.addEventListener("keydown",d,{capture:!0})}function E(){window.removeEventListener("pointermove",c,{capture:!0}),window.removeEventListener("mousemove",c,{capture:!0}),window.removeEventListener("click",p,{capture:!0}),window.removeEventListener("keydown",d,{capture:!0}),t=null}typeof chrome<"u"&&chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener((b,g,u)=>(b.type==="TOGGLE_INSPECTION"?(s(b.payload),u({isEnabled:o})):b.type==="GET_STATE"&&u({isEnabled:o}),!0)),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",r):r()})();})();
